/*
  Warnings:

  - You are about to drop the column `sessionMemberId` on the `CommentThread` table. All the data in the column will be lost.
  - You are about to drop the `SessionMember` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `SessionMembersOnMessages` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `userId` to the `CommentThread` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "CommentThread" DROP CONSTRAINT "CommentThread_sessionMemberId_fkey";

-- DropForeignKey
ALTER TABLE "SessionDocument" DROP CONSTRAINT "SessionDocument_ownerId_fkey";

-- DropForeignKey
ALTER TABLE "SessionMember" DROP CONSTRAINT "SessionMember_sessionId_fkey";

-- DropForeignKey
ALTER TABLE "SessionMembersOnMessages" DROP CONSTRAINT "SessionMembersOnMessages_messageId_fkey";

-- DropForeignKey
ALTER TABLE "SessionMembersOnMessages" DROP CONSTRAINT "SessionMembersOnMessages_recipientId_fkey";

-- DropForeignKey
ALTER TABLE "SessionMembersOnMessages" DROP CONSTRAINT "SessionMembersOnMessages_senderId_fkey";

-- AlterTable
ALTER TABLE "CommentThread" DROP COLUMN "sessionMemberId",
ADD COLUMN     "userId" TEXT NOT NULL;

-- DropTable
DROP TABLE "SessionMember";

-- DropTable
DROP TABLE "SessionMembersOnMessages";

-- CreateTable
CREATE TABLE "UsersSessions" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "sessionDocumentId" TEXT NOT NULL,

    CONSTRAINT "UsersSessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SessionMessages" (
    "sessionId" TEXT NOT NULL,
    "senderId" TEXT NOT NULL,
    "recipientId" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,

    CONSTRAINT "SessionMessages_pkey" PRIMARY KEY ("senderId","recipientId","messageId")
);

-- AddForeignKey
ALTER TABLE "UsersSessions" ADD CONSTRAINT "UsersSessions_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "Session"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UsersSessions" ADD CONSTRAINT "UsersSessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UsersSessions" ADD CONSTRAINT "UsersSessions_sessionDocumentId_fkey" FOREIGN KEY ("sessionDocumentId") REFERENCES "SessionDocument"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SessionDocument" ADD CONSTRAINT "SessionDocument_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SessionMessages" ADD CONSTRAINT "SessionMessages_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "Session"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SessionMessages" ADD CONSTRAINT "SessionMessages_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES "UsersSessions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SessionMessages" ADD CONSTRAINT "SessionMessages_recipientId_fkey" FOREIGN KEY ("recipientId") REFERENCES "UsersSessions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SessionMessages" ADD CONSTRAINT "SessionMessages_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES "Message"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommentThread" ADD CONSTRAINT "CommentThread_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
