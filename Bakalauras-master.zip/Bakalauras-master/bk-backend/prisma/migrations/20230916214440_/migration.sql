/*
  Warnings:

  - You are about to drop the column `ownerId` on the `SessionDocument` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "SessionDocument" DROP CONSTRAINT "SessionDocument_ownerId_fkey";

-- AlterTable
ALTER TABLE "SessionDocument" DROP COLUMN "ownerId";
