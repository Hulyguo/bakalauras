-- DropForeignKey
ALTER TABLE "UsersSessions" DROP CONSTRAINT "UsersSessions_sessionDocumentId_fkey";

-- AlterTable
ALTER TABLE "UsersSessions" ALTER COLUMN "sessionDocumentId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "UsersSessions" ADD CONSTRAINT "UsersSessions_sessionDocumentId_fkey" FOREIGN KEY ("sessionDocumentId") REFERENCES "SessionDocument"("id") ON DELETE SET NULL ON UPDATE CASCADE;
