/*
  Warnings:

  - You are about to drop the column `sessionId` on the `CommentThread` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `CommentThread` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "CommentThread" DROP CONSTRAINT "CommentThread_sessionId_fkey";

-- DropForeignKey
ALTER TABLE "CommentThread" DROP CONSTRAINT "CommentThread_userId_fkey";

-- AlterTable
ALTER TABLE "CommentThread" DROP COLUMN "sessionId",
DROP COLUMN "userId",
ADD COLUMN     "usersSessionsId" TEXT;

-- AddForeignKey
ALTER TABLE "CommentThread" ADD CONSTRAINT "CommentThread_usersSessionsId_fkey" FOREIGN KEY ("usersSessionsId") REFERENCES "UsersSessions"("id") ON DELETE SET NULL ON UPDATE CASCADE;
