-- AlterTable
ALTER TABLE "CommentThread" ADD COLUMN     "sessionDocumentId" TEXT;

-- AddForeignKey
ALTER TABLE "CommentThread" ADD CONSTRAINT "CommentThread_sessionDocumentId_fkey" FOREIGN KEY ("sessionDocumentId") REFERENCES "SessionDocument"("id") ON DELETE SET NULL ON UPDATE CASCADE;
