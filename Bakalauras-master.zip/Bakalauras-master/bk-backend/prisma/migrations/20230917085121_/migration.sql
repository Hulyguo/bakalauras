/*
  Warnings:

  - You are about to drop the column `usersSessionsId` on the `CommentThread` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "CommentThread" DROP CONSTRAINT "CommentThread_usersSessionsId_fkey";

-- AlterTable
ALTER TABLE "CommentThread" DROP COLUMN "usersSessionsId";
