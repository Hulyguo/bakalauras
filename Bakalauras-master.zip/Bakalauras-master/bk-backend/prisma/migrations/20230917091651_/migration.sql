/*
  Warnings:

  - The primary key for the `SessionMessages` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `messageId` on the `SessionMessages` table. All the data in the column will be lost.
  - You are about to drop the `Message` table. If the table is not empty, all the data it contains will be lost.
  - The required column `id` was added to the `SessionMessages` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `message` to the `SessionMessages` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "SessionMessages" DROP CONSTRAINT "SessionMessages_messageId_fkey";

-- AlterTable
ALTER TABLE "SessionMessages" DROP CONSTRAINT "SessionMessages_pkey",
DROP COLUMN "messageId",
ADD COLUMN     "id" TEXT NOT NULL,
ADD COLUMN     "message" TEXT NOT NULL,
ADD COLUMN     "sent" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD CONSTRAINT "SessionMessages_pkey" PRIMARY KEY ("id");

-- DropTable
DROP TABLE "Message";
