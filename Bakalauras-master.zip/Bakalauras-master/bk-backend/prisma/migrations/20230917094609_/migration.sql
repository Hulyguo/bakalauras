/*
  Warnings:

  - You are about to drop the column `author` on the `Comment` table. All the data in the column will be lost.
  - You are about to drop the column `sessionOwner` on the `Session` table. All the data in the column will be lost.
  - You are about to drop the column `sessionDocumentId` on the `UsersSessions` table. All the data in the column will be lost.
  - Added the required column `authorId` to the `Comment` table without a default value. This is not possible if the table is not empty.
  - Added the required column `authorId` to the `CommentThread` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userSessionId` to the `SessionDocument` table without a default value. This is not possible if the table is not empty.
  - Added the required column `role` to the `UsersSessions` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "UserSessionRole" AS ENUM ('MEMBER', 'ADMIN');

-- DropForeignKey
ALTER TABLE "UsersSessions" DROP CONSTRAINT "UsersSessions_sessionDocumentId_fkey";

-- AlterTable
ALTER TABLE "Comment" DROP COLUMN "author",
ADD COLUMN     "authorId" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "CommentThread" ADD COLUMN     "authorId" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "Session" DROP COLUMN "sessionOwner";

-- AlterTable
ALTER TABLE "SessionDocument" ADD COLUMN     "userSessionId" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "UsersSessions" DROP COLUMN "sessionDocumentId",
ADD COLUMN     "role" "UserSessionRole" NOT NULL;

-- AddForeignKey
ALTER TABLE "SessionDocument" ADD CONSTRAINT "SessionDocument_userSessionId_fkey" FOREIGN KEY ("userSessionId") REFERENCES "UsersSessions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommentThread" ADD CONSTRAINT "CommentThread_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Comment" ADD CONSTRAINT "Comment_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
