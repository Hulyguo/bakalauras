-- CreateTable
CREATE TABLE "DocumentOperations" (
    "id" INTEGER NOT NULL,
    "sessionDocumentId" TEXT NOT NULL,
    "operations" JSONB NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "DocumentOperations_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "DocumentOperations" ADD CONSTRAINT "DocumentOperations_sessionDocumentId_fkey" FOREIGN KEY ("sessionDocumentId") REFERENCES "SessionDocument"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DocumentOperations" ADD CONSTRAINT "DocumentOperations_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
