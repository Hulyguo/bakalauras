-- AlterTable
CREATE SEQUENCE documentoperations_id_seq;
ALTER TABLE "DocumentOperations" ALTER COLUMN "id" SET DEFAULT nextval('documentoperations_id_seq');
ALTER SEQUENCE documentoperations_id_seq OWNED BY "DocumentOperations"."id";
