-- AlterTable
ALTER TABLE "SessionDocument" ADD COLUMN     "grade" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "gradeNote" TEXT NOT NULL DEFAULT '';
