-- CreateEnum
CREATE TYPE "DocumentStatus" AS ENUM ('IN_PROGRESS', 'SUBMITTED', 'CANCELLED');

-- AlterTable
ALTER TABLE "SessionDocument" ADD COLUMN     "status" "DocumentStatus" NOT NULL DEFAULT 'SUBMITTED';
