-- AlterTable
ALTER TABLE "SessionDocument" ALTER COLUMN "status" SET DEFAULT 'IN_PROGRESS';
