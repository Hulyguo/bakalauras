import type { CookieSerializeOptions } from '@fastify/cookie';

export const HttpOnlyCookieOptions = (): CookieSerializeOptions => ({
  secure: true,
  httpOnly: true,
  expires: new Date(Date.now() + parseInt(process.env?.['USER_SESSION_TOKEN_EXPIRE'] as string, 10)),
  sameSite: 'none' as const,
  domain: process.env?.['APP_DOMAIN'],
  ...(process.env?.['NODE_ENV'] === 'production' ? { sameSite: 'lax' } : {}),
});
