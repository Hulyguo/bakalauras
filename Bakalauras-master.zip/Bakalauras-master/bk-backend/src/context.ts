import { inferAsyncReturnType } from '@trpc/server';
import { CreateFastifyContextOptions } from '@trpc/server/adapters/fastify';
import { servicesContainer } from './inversify.config';
import { PrismaClientService } from './services/PrismaClientService';
import { RedisClientService } from './services/RedisClient';

const redisClientService = servicesContainer.get(RedisClientService);
const prismaClientService = servicesContainer.get(PrismaClientService);

export const createContext = async ({ req, res }: CreateFastifyContextOptions) => {
  const sessionToken = req.cookies?.sessionToken;
  const userId = await redisClientService.retrieveRecord(sessionToken ?? '');
  if (!userId) {
    return { req, res };
  }

  const user = await prismaClientService.user.findFirst({ where: { id: userId } });
  return { req, res, user };
}

export type Context = inferAsyncReturnType<typeof createContext>;
export type ProtectedContext = Required<inferAsyncReturnType<typeof createContext>>