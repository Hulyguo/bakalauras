import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';

@injectable()
export class CommentDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async addComment(authorId: string, commentThreadId: string, text: string) {
    const addedComment = await this.prismaClientService.comment.create({
      data: {
        authorId,
        text,
        commentThreadId,
      }
    });
    return addedComment;
  }
}

