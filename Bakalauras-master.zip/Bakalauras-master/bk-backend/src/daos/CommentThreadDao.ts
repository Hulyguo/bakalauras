import { CommentThread } from '@prisma/client';
import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';
import { CommentThreadStatus } from '../types';

@injectable()
export class CommentThreadDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async addCommentThread(id: string, status: CommentThreadStatus, sessionDocumentId: string, authorId: string) {
    const addedCommentThread = await this.prismaClientService.commentThread.create({
      data: {
        id,
        status,
        sessionDocumentId,
        authorId,
      }
    });
    return addedCommentThread;
  }

  public async getCommentThreads({ documentId }: { documentId: string }) {
    const commentThreads = await this.prismaClientService.commentThread.findMany({
      where: {
        sessionDocumentId: documentId
      },
      include: {
        comments: {
          include: {
            author: {
              select: {
                firstName: true,
                lastName: true,
              }
            }
          }
        },
        author: {
          select: {
            firstName: true,
            lastName: true,
          }
        }
      }
    });

    const threads = commentThreads.map((thread: Partial<CommentThread>) => {
      return thread;
    })
    return threads;
  }

  public async updateCommentThreadStatus(threadId: string, status: CommentThreadStatus) {
    const updatedCommentThread = await this.prismaClientService.commentThread.update({
      data: {
        status,
      },
      where: {
        id: threadId
      }
    });
    return updatedCommentThread;
  }

  public async findById(threadId: string) {
    const commentThread = await this.prismaClientService.commentThread.findFirst({
      where: {
        id: threadId
      }
    });
    return commentThread;
  }
}

