import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';

@injectable()
export class DocumentOperationsDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async addOperations(userId: string, operations: any[], sessionDocumentId: string) {

    const addedOperations = await this.prismaClientService.documentOperations.create({
      data: {
        operations,
        userId,
        sessionDocumentId
      }
    });
    return addedOperations;
  }

  public async getOperations(sessionDocumentId: string) {
    const operations = await this.prismaClientService.documentOperations.findMany({
      where: {
        sessionDocumentId
      }
    });
    return operations;
  }
}

