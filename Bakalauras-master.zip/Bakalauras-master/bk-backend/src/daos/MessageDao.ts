import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';

@injectable()
export class MessageDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async addMessageToSession({ message, recipientId, senderId, sessionId }: { message: string, recipientId: string, senderId: string, sessionId: string }) {
    const addedMessage = await this.prismaClientService.sessionMessages.create({
      data: {
        message,
        sessionId,
        recipientId,
        senderId,
      },
    });
    return addedMessage
  }

  public async getSessionMessages({ sessionId, userId }: { sessionId: string, userId: string }) {
    const messages = await this.prismaClientService.sessionMessages.findMany({
      select: {
        recipientId: true,
        senderId: true,
        id: true,
        message: true,
        sent: true,
      },
      where: {
        OR: [
          { sessionId, recipientId: userId },
          { sessionId, senderId: userId }
        ],
      },
    });

    const updatedMessages = messages.map((message) => ({
      isSender: userId === message.senderId,
      message: message.message,
      id: message.id,
      sent: message.sent,
    }));
    return updatedMessages;
  }
}

