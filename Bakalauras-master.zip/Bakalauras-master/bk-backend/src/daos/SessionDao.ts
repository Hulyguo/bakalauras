import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';
import { SessionStatus, User } from '@prisma/client';

@injectable()
export class SessionDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async initializeSession({ sessionOwner, sessionName }: { sessionOwner: string, sessionName: string }) {

    const session = await this.prismaClientService.usersSessions.create({
      data: {
        user: {
          connect: {
            id: sessionOwner
          }
        },
        role: "ADMIN",
        session: {
          create: {
            sessionName
          }
        },
      }
    });
    return session;
  }

  public async updateSessionStatus(sessionId: string, sessionStatus: SessionStatus) {
    const session = await this.prismaClientService.session.update({
      data: {
        sessionStatus
      },
      where: {
        id: sessionId
      }
    });
    return session;
  }

  public async findSessionById(sessionId: string) {
    const sessions = await this.prismaClientService.session.findFirst({
      where: {
        id: sessionId
      },
      include: {
        usersSessions: {
          where: {
            sessionId
          },
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
              }
            },
          }
        }
      }
    });
    return sessions;
  }

  public async findUserSessionByUserId({ userId, sessionId }: { userId: string, sessionId: string }) {
    const userSession = await this.prismaClientService.usersSessions.findFirst({
      where: {
        userId,
        sessionId
      }
    });
    return userSession;
  }

  public async findSessionAdminIdBySessionId({ sessionId }: { sessionId: string }) {
    const userSession = await this.prismaClientService.usersSessions.findFirst({
      where: {
        role: 'ADMIN',
        sessionId,
      }
    });
    return userSession?.userId;
  }

  public async getDetailedSessionsByUserId(userId: string) {
    const userSessions = await this.prismaClientService.usersSessions.findMany({
      where: {
        userId,
      },
      select: {
        session: {
          select: {
            id: true,
            sessionName: true,
            startedAt: true,
            sessionStatus: true,
            usersSessions: {
              where: {
                userId,
              },
              select: {
                id: true,
                role: true,
                session: {
                  select: {
                    id: true,
                    sessionName: true,
                    sessionStatus: true,
                    startedAt: true,
                  },
                },
                sessionDocuments: {
                  select: {
                    id: true,
                    grade: true,
                    gradeNote: true,
                    status: true,
                    userSessionId: true,
                  }
                },
                user: {
                  select: {
                    id: true,
                    firstName: true,
                    lastName: true,
                  }
                }
              }
            }
          }
        }
      },
    });

    const sessionUsersMap: Record<string, Pick<User, 'id' | 'firstName' | 'lastName'>[]> = {};

    userSessions.forEach(userSession => {
      if (!sessionUsersMap[userSession.session.id]) {
        sessionUsersMap[userSession.session.id] = [];
      }

      sessionUsersMap[userSession.session.id].push({
        id: userSession.session.usersSessions[0].user.id,
        firstName: userSession.session.usersSessions[0].user.firstName,
        lastName: userSession.session.usersSessions[0].user.lastName
      });
    });

    const mappedSessions = userSessions.map((userSession) => ({
      id: userSession.session.usersSessions[0].id,
      role: userSession.session.usersSessions[0].role,
      users: sessionUsersMap[userSession.session.id],
      session: userSession.session,
      sessionDocuments: userSession.session.usersSessions[0].sessionDocuments,
    }))

    return mappedSessions;
  }
}