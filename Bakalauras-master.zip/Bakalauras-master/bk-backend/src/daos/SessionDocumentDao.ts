import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';
import { DocumentStatus } from '@prisma/client';

const initialDocument = [
  {
    type: 'paragraph',
    children: [
      { text: '' },
    ],
  },
];

@injectable()
export class SessionDocumentDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async createSessionDocuments({ userSessionIds, sessionId }: { userSessionIds: string[], sessionId: string }) {
    const documentsToAdd = userSessionIds.map(userId => ({
      document: JSON.stringify(initialDocument),
      userSessionId: userId
    }));

    if (!documentsToAdd.length) {
      return [];
    }

    const sessionDocuments = await this.prismaClientService.sessionDocument.createMany({
      data: documentsToAdd
    });
    return sessionDocuments;
  }

  public async getSessionDocument(ownerId: string, sessionId: string) {
    const sessionDocument = await this.prismaClientService.usersSessions.findFirst({
      where: {
        userId: ownerId,
        sessionId
      },
      select: {
        sessionDocuments: true
      }
    });
    return sessionDocument;
  }

  public async gradeSessionDocument({ sessionDocumentId, gradeNote, grade }: { sessionDocumentId: string, gradeNote: string, grade: number }) {
    const sessionDocument = await this.prismaClientService.sessionDocument.update({
      where: {
        id: sessionDocumentId,
      },
      data: {
        grade,
        gradeNote
      },
    });
    return sessionDocument;
  }

  public async changeDocumentState({ sessionDocumentId, status }: { sessionDocumentId: string, status: DocumentStatus }) {
    const updatedDocument = await this.prismaClientService.sessionDocument.update({
      data: {
        status,
      },
      where: {
        id: sessionDocumentId
      }
    });
    return updatedDocument;
  }

  public async updateSessionDocument(sessionDocumentId: string, document: string) {

    const updatedDocument = await this.prismaClientService.sessionDocument.update({
      data: {
        document,
      },
      where: {
        id: sessionDocumentId
      }
    });
    return updatedDocument;
  }
}

