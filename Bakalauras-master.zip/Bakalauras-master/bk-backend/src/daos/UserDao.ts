import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';

@injectable()
export class UserDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async isEmailUnique({ email }: { email: string }) {
    const foundUser = await this.prismaClientService.user.findFirst({
      where: { email },
    });

    if (!foundUser) return true;
    return false;
  }

  public async isUsernameUnique({ username }: { username: string }) {
    const foundUser = await this.prismaClientService.user.findFirst({
      where: { username }
    });

    if (!foundUser) return true;
    return false;
  }
}

