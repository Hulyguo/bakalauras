import { injectable, inject } from 'inversify';
import { PrismaClientService } from '../services/PrismaClientService';
import { TRPCError } from '@trpc/server';

@injectable()
export class UserSessionsDao {
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;

  public async addUserSessions(sessionId: string, userId: string) {

    try {
      const addedMember = await this.prismaClientService.usersSessions.create({
        data: {
          role: "MEMBER",
          userId,
          sessionId,
        },
        include: {
          user: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
            }
          }
        }
      });
      return addedMember;
    } catch (e) {
      throw new TRPCError({
        message: 'Invalid session ID or username',
        code: 'BAD_REQUEST',
      });
    }
  }

  public async getUserSessions(sessionId: string) {
    const sessionMembers = await this.prismaClientService.usersSessions.findMany({
      where: {
        sessionId,
        NOT: {
          role: "ADMIN"
        }
      },
      select: {
        role: true,
        id: true,
        user: {
          select: {
            firstName: true,
            lastName: true,
            id: true,
          }
        }
      },
    });
    return sessionMembers.map(({ role, id, user: { firstName, id: userId, lastName } }) => ({
      id: userId,
      firstName,
      lastName,
      userSessionId: id,
      role
    }));
  }

  public async findUserSessionById(id: string) {
    const sessionMember = await this.prismaClientService.usersSessions.findFirst({
      where: { id }
    });
    return sessionMember;
  }

  public async find({ sessionId, userId }: { sessionId: string, userId: string }) {
    const userSession = await this.prismaClientService.usersSessions.findFirst({
      where: {
        sessionId,
        userId,
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
          }
        }
      }
    });
    return userSession;
  }

  public async getUserSessionsWithMessages(sessionId: string) {
    const sessionMembers = await this.prismaClientService.usersSessions.findMany({
      where: { sessionId },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
          }
        },
        sessionDocuments: {
          select: {
            id: true,
          }
        },
        session: {
          select: {
            sessionMessages: {
              select: {
                senderId: true,
                recipientId: true,
                message: true
              }
            }
          }
        }
      }
    });
    return sessionMembers;
  }
}

