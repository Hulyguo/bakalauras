import { object, string } from "zod";

export const loginDTO = object({
  username: string().min(1, 'Invalid username'),
  password: string().min(1, 'Enter a password'),
});

export const registerDTO = object({
  username: string().min(1, 'Invalid username'),
  password: string().min(8, 'Password has to be at least 8 characters long'),
  firstName: string().min(1, 'Invalid first name'),
  lastName: string().min(1, 'Invalid first name'),
  email: string().min(1, 'Invalid email'),
});

export const loginPayload = object({
  csrfToken: string(),
});