import { nativeEnum, number, object, string } from "zod";
import { CommentThreadStatus } from "../types";


export const addCommentThreadDTO = object({
  id: string(),
  status: nativeEnum(CommentThreadStatus),
  documentId: string(),
});

export const addCommentToThreadDTO = object({
  commentThreadId: string(),
  text: string(),
});

export const getCommentThreadsDTO = object({
  documentId: string(),
});

export const updateCommentThreadStatus = object({
  status: nativeEnum(CommentThreadStatus),
  id: string()
});

export const onAddCommentToThread = object({
  documentOwnerId: string().optional(),
  activeHeaderIndex: number().optional()
});

export const onAddCommentThread = object({
  documentId: string()
});
