import { object, string } from "zod";

export const sendMessageDTO = object({
  message: string(),
  recipientId: string().optional(),
  sessionId: string()
});

export const onMessageSentDTO = object({
  sessionId: string(),
});

export const getMessagesDTO = object({
  sessionId: string()
});