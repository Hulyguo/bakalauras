import { DocumentStatus, SessionStatus } from "@prisma/client";
import { any, array, nativeEnum, number, object, string } from "zod";

const sessionIdValidation = string().min(1, 'Enter a session id');

export const joinSessionDTO = object({
  sessionId: sessionIdValidation
});

export const initializeSessionDTO = object({
  sessionName: string()
});

export const onJoinSessionDTO = object({
  sessionId: sessionIdValidation
});

export const onSessionStatusChangeDTO = object({
  sessionId: sessionIdValidation
});

export const onDocumentUpdateDTO = object({
  userId: string(),
  documentId: string(),
});

export const changeSessionStatusDTO = object({
  sessionId: sessionIdValidation,
  sessionStatus: nativeEnum(SessionStatus),
});

export const getSessionDTO = object({
  sessionId: sessionIdValidation
});

export const getSessionMembersDTO = object({
  sessionId: sessionIdValidation
});

export const getSessionRoleDTO = object({
  sessionId: sessionIdValidation,
});

export const getSessionMembers = object({
  sessionId: sessionIdValidation
});

export const updateDocumentDTO = object({
  documentId: string(),
  document: string(),
  sessionId: string(),
  operations: array(any()),
});

export const getDocumentDTO = object({
  ownerId: string().optional(),
  sessionId: string(),
});

export const getDocumentOperationsDTO = object({
  sessionDocumentId: string(),
});

export const fetchMySessionDocumentsDTO = object({
  sessionId: string(),
});

export const submitGradeDTO = object({
  grade: number(),
  gradeNote: string(),
  sessionDocumentId: string(),
});

export const changeStateDTO = object({
  sessionDocumentId: string(),
  status: nativeEnum(DocumentStatus),
});