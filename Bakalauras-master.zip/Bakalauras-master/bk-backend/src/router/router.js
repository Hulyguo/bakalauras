"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appRouter = void 0;
const authenticationRouter_1 = require("./routers/authenticationRouter");
const commentRouter_1 = require("./routers/commentRouter");
const documentRouter_1 = require("./routers/documentRouter");
const messageRouter_1 = require("./routers/messageRouter");
const sessionRouter_1 = require("./routers/sessionRouter");
const trpc_1 = require("./trpc");
exports.appRouter = (0, trpc_1.router)({
    document: documentRouter_1.documentRouter,
    session: sessionRouter_1.sessionRouter,
    message: messageRouter_1.messageRouter,
    comment: commentRouter_1.commentRouter,
    authentication: authenticationRouter_1.authenticationRouter
});
