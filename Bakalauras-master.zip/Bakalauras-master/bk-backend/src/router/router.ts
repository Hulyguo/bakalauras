
import { authenticationRouter } from './routers/authenticationRouter';
import { commentRouter } from './routers/commentRouter';
import { documentRouter } from './routers/documentRouter';
import { messageRouter } from './routers/messageRouter';
import { sessionRouter } from './routers/sessionRouter';
import { router } from './trpc';


export const appRouter = router({
  document: documentRouter,
  session: sessionRouter,
  message: messageRouter,
  comment: commentRouter,
  authentication: authenticationRouter
});

// export type definition of API
export type AppRouter = typeof appRouter;