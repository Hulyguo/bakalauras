import { EventEmitter } from "stream";
import { protectedProcedure, publicProcedure, router } from "../trpc";
import { loginDTO, loginPayload, registerDTO } from "../../dtos/AuthenticationDTO";
import { servicesContainer } from "../../inversify.config";
import { AuthenticationService } from "../../services/AuthenticationService";
import { HttpOnlyCookieOptions } from "../../config/HttpOnlyCookieOptions";
import { UserDao } from "../../daos/UserDao";

const ee = new EventEmitter();

const authenticationService = servicesContainer.get(AuthenticationService);
const userDao = servicesContainer.get(UserDao);

export const authenticationRouter = router({
  login: publicProcedure.input(loginDTO).mutation(async ({ input: { username, password }, ctx }) => {
    const { csrfToken, csrfSecret, randomHash } = await authenticationService.login(username, password);
    const cookieOpts = HttpOnlyCookieOptions();

    ctx.res.setCookie('sessionToken', randomHash, cookieOpts);
    ctx.res.setCookie('_csrf', csrfSecret, { ...cookieOpts, httpOnly: false });

    return loginPayload.parse({ csrfToken });
  }),
  register: publicProcedure.input(registerDTO).mutation(async ({ input }) => {
    const isEmailUnique = await userDao.isEmailUnique({ email: input.email });
    const isUsernameUnique = await userDao.isUsernameUnique({ username: input.username });

    if (isEmailUnique && isUsernameUnique) {
      await authenticationService.register(input);
    }

    return { isEmailUnique, isUsernameUnique };
  }),
  myUser: protectedProcedure.query(({ ctx: { user } }) => {
    return { valid: true, user };
  }),
});