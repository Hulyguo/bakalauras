import { Comment, CommentThread } from "@prisma/client";
import { observable } from "@trpc/server/observable";
import { EventEmitter } from "stream";
import { CommentDao } from "../../daos/CommentDao";
import { CommentThreadDao } from "../../daos/CommentThreadDao";
import { addCommentThreadDTO, addCommentToThreadDTO, getCommentThreadsDTO, onAddCommentThread, onAddCommentToThread, updateCommentThreadStatus } from "../../dtos/CommentThreadDTO";
import { servicesContainer } from "../../inversify.config";
import { CommentService } from "../../services/CommentService";
import { protectedProcedure, publicProcedure, router } from "../trpc";

const ee = new EventEmitter();

export const commentRouter = router({
  addCommentThread: protectedProcedure.input(addCommentThreadDTO).mutation(async ({ input, ctx }) => {
    const commentThreadDao = servicesContainer.get(CommentThreadDao);
    const { id, status, documentId } = input;
    const addedCommentThread = await commentThreadDao.addCommentThread(id, status, documentId, ctx.user.id);
    ee.emit('addCommentThread', addedCommentThread);
    return addedCommentThread;
  }),
  addCommentToThread: protectedProcedure.input(addCommentToThreadDTO).mutation(async ({ input, ctx }) => {
    const { commentThreadId, text } = input;
    const commentDao = servicesContainer.get(CommentDao);

    const addedComment = await commentDao.addComment(ctx.user.id, commentThreadId, text)
    ee.emit('addCommentToThread', addedComment);
    return addedComment;
  }),
  getCommentThreads: protectedProcedure.input(getCommentThreadsDTO).query(async ({ input }) => {
    const { documentId } = input;
    const commentService = servicesContainer.get(CommentService);
    const commentThreads = await commentService.getCommentThreads({ documentId });
    return commentThreads;
  }),
  updateCommentThreadStatus: protectedProcedure.input(updateCommentThreadStatus).mutation(async ({ input }) => {
    const { id, status } = input;
    const commentThreadDao = servicesContainer.get(CommentThreadDao);
    const updatedThread = commentThreadDao.updateCommentThreadStatus(id, status);
    return updatedThread;
  }),
  onAddCommentThread: publicProcedure.input(onAddCommentThread).subscription(({ input, ctx }) => {
    return observable((emit) => {
      const onAddCommentThread = async (addedCommentThread: CommentThread) => {
        emit.next(addedCommentThread);
      }

      ee.on('addCommentThread', onAddCommentThread);

      return () => ee.off('addCommentThread', onAddCommentThread);
    })
  }),
  onAddCommentToThread: publicProcedure.input(onAddCommentToThread).subscription(({ input }) => {
    return observable((emit) => {
      const onAddCommentToThread = async (addedComment: Comment) => {
        emit.next(addedComment);
      }

      ee.on('addCommentToThread', onAddCommentToThread);

      return () => ee.off('addCommentToThread', onAddCommentToThread);
    })
  }),
});