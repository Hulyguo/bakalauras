import { EventEmitter } from "stream";
import { changeStateDTO, fetchMySessionDocumentsDTO, getDocumentDTO, getDocumentOperationsDTO, onDocumentUpdateDTO, submitGradeDTO, updateDocumentDTO } from "../../dtos/SessionDTO";
import { protectedProcedure, publicProcedure, router } from "../trpc";
import { observable } from '@trpc/server/observable';
import { SessionDocument } from "@prisma/client";
import { SessionDocumentDao } from "../../daos/SessionDocumentDao";
import { servicesContainer } from "../../inversify.config";
import { DocumentOperationsDao } from "../../daos/DocumentOperationsDao";

const ee = new EventEmitter();

export const documentRouter = router({
  onDocumentUpdate: publicProcedure.input(onDocumentUpdateDTO).subscription(({ input: { documentId, userId } }) => {
    return observable((emit) => {
      const onDocumentUpdate = (sessionDocument: SessionDocument, updatedById: string) => {
        if (sessionDocument.id === documentId && updatedById !== userId) {
          emit.next(sessionDocument);
        }
      }

      ee.on('updateDocument', onDocumentUpdate);

      return () => ee.off('updateDocument', onDocumentUpdate);
    })
  }),
  updateDocument: protectedProcedure.input(updateDocumentDTO).mutation(async ({ input, ctx }) => {
    const { document, operations, documentId } = input;
    const sessionDocumentDao = servicesContainer.get(SessionDocumentDao);
    const documentOperationsDao = servicesContainer.get(DocumentOperationsDao);

    const updatedDocument = await sessionDocumentDao.updateSessionDocument(documentId, document);
    await documentOperationsDao.addOperations(ctx.user.id, operations, documentId);

    ee.emit('updateDocument', updatedDocument, ctx.user.id);
  }),
  getDocument: protectedProcedure.input(getDocumentDTO).query(async ({ input, ctx }) => {
    const { ownerId, sessionId } = input;
    const sessionDocumentDao = servicesContainer.get(SessionDocumentDao);
    const sessionDocument = await sessionDocumentDao.getSessionDocument(ownerId ?? ctx.user.id, sessionId);
    return sessionDocument;
  }),
  getDocumentOperations: protectedProcedure.input(getDocumentOperationsDTO).query(async ({ input, ctx }) => {
    const { sessionDocumentId } = input;
    const documentOperationsDao = servicesContainer.get(DocumentOperationsDao);
    const documentOperations = await documentOperationsDao.getOperations(sessionDocumentId);
    return documentOperations;
  }),
  fetchMySessionDocuments: protectedProcedure.input(fetchMySessionDocumentsDTO).mutation(async ({ input, ctx }) => {
    const { sessionId } = input;
    const sessionDocumentDao = servicesContainer.get(SessionDocumentDao);
    const sessionDocument = await sessionDocumentDao.getSessionDocument(ctx.user.id, sessionId);
    return sessionDocument;
  }),
  submitGrade: protectedProcedure.input(submitGradeDTO).mutation(async ({ input }) => {
    const sessionDocumentDao = servicesContainer.get(SessionDocumentDao);
    const sessionDocument = await sessionDocumentDao.gradeSessionDocument(input);
    return sessionDocument;
  }),
  changeState: protectedProcedure.input(changeStateDTO).mutation(async ({ input }) => {
    const sessionDocumentDao = servicesContainer.get(SessionDocumentDao);
    const sessionDocument = await sessionDocumentDao.changeDocumentState(input);
    return sessionDocument;
  }),
});