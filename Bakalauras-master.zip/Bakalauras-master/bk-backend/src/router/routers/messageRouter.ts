import { EventEmitter } from "stream";
import { protectedProcedure, publicProcedure, router } from "../trpc";
import { observable } from '@trpc/server/observable';
import { servicesContainer } from "../../inversify.config";
import { getMessagesDTO, onMessageSentDTO, sendMessageDTO } from "../../dtos/MessageDTO";
import { MessageDao } from "../../daos/MessageDao";
import { SessionDao } from "../../daos/SessionDao";
import { SessionMessages } from "@prisma/client";

const ee = new EventEmitter();

export const messageRouter = router({
  onMessageSent: publicProcedure.input(onMessageSentDTO).subscription(({ input, ctx }) => {
    return observable(emit => {
      const onMessageSent = (sentMessage: SessionMessages) => {
        emit.next(sentMessage);
      }

      ee.on('sendMessage', onMessageSent);

      return () => ee.off('sendMessage', onMessageSent);
    })
  }),
  sendMessage: protectedProcedure.input(sendMessageDTO).mutation(async ({ input, ctx }) => {
    const { message, recipientId, sessionId } = input;
    const messageDao = servicesContainer.get(MessageDao);
    const sessionDao = servicesContainer.get(SessionDao);
    const targetRecipientId = recipientId ?? (await sessionDao.findSessionAdminIdBySessionId({ sessionId }));
    if (!targetRecipientId) return null;

    const sentMessage = await messageDao.addMessageToSession({ message, recipientId: targetRecipientId, senderId: ctx.user.id, sessionId });
    ee.emit('sendMessage', sentMessage);
    return sentMessage;
  }),
  getMessages: protectedProcedure.input(getMessagesDTO).query(async ({ input, ctx }) => {
    const { sessionId } = input;
    const messageDao = servicesContainer.get(MessageDao);

    const messages = await messageDao.getSessionMessages({ sessionId, userId: ctx.user.id });
    return messages;
  }),
});