import { protectedProcedure, publicProcedure, router } from "../trpc";
import { observable } from '@trpc/server/observable';
import { SessionDao } from "../../daos/SessionDao";
import { changeSessionStatusDTO, getSessionDTO, getSessionMembersDTO, getSessionRoleDTO, initializeSessionDTO, joinSessionDTO, onJoinSessionDTO, onSessionStatusChangeDTO } from "../../dtos/SessionDTO";
import { servicesContainer } from "../../inversify.config";
import { SessionService } from "../../services/SessionService";
import { Session, SessionStatus, UsersSessions } from "@prisma/client";
import { EventEmitter } from "events";
import { UserSessionRole } from "../../types";
import { UserSessionsDao } from "../../daos/UserSessionsDao";

export const sessionEe = new EventEmitter();

export const sessionRouter = router({
  initializeSession: protectedProcedure.input(initializeSessionDTO).mutation(async ({ ctx, input: { sessionName } }) => {
    const sessionDao = servicesContainer.get(SessionDao);
    const { sessionId } = await sessionDao.initializeSession({ sessionName, sessionOwner: ctx.user.id });
    return { sessionId };
  }),
  joinSession: protectedProcedure.input(joinSessionDTO).mutation(async ({ input: { sessionId }, ctx }) => {
    const sessionService = servicesContainer.get(SessionService);
    const addedSessionMember = await sessionService.joinSession({ sessionId, userId: ctx.user.id });
    return addedSessionMember;
  }),
  onJoinSession: publicProcedure.input(onJoinSessionDTO).subscription(({ input }) => {
    return observable((emit) => {
      const onJoinSession = (sessionMember: UsersSessions) => {
        if (sessionMember.sessionId !== input.sessionId) {
          return;
        }

        emit.next(sessionMember);
      }

      sessionEe.on('joinSession', onJoinSession);

      return () => sessionEe.off('joinSession', onJoinSession);
    })
  }),
  updateSessionStatus: protectedProcedure.input(changeSessionStatusDTO).mutation(async ({ input }) => {
    const { sessionId, sessionStatus } = input;
    const sessionDao = servicesContainer.get(SessionDao);
    const sessionService = servicesContainer.get(SessionService);

    const currentSession = await sessionDao.findSessionById(sessionId);
    if (currentSession?.sessionStatus === sessionStatus) return;

    const session = await sessionDao.updateSessionStatus(input.sessionId, input.sessionStatus);

    if (sessionStatus === SessionStatus.InProgress) {
      await sessionService.initializeSessionDocuments(sessionId);
    }
    sessionEe.emit('updateSessionStatus', session);
  }),
  onSessionStatusChange: publicProcedure.input(onSessionStatusChangeDTO).subscription(({ input }) => {
    return observable((emit) => {
      const onSessionStatusChange = (session: Session) => {
        emit.next(session);
      }

      sessionEe.on('updateSessionStatus', onSessionStatusChange);

      return () => sessionEe.off('updateSessionStatus', onSessionStatusChange);
    })
  }),
  getUserSessions: protectedProcedure.query(async ({ ctx }) => {
    const sessionDao = servicesContainer.get(SessionDao);
    const detailedSessions = await sessionDao.getDetailedSessionsByUserId(ctx.user.id);
    return detailedSessions;
  }),
  getSession: protectedProcedure.input(getSessionDTO).query(async ({ input }) => {
    const sessionDao = servicesContainer.get(SessionDao);
    const session = await sessionDao.findSessionById(input.sessionId);
    return session;
  }),
  getSessionMembers: protectedProcedure.input(getSessionMembersDTO).query(async ({ input }) => {
    const userSessionsDao = servicesContainer.get(UserSessionsDao);
    const sessionMembers = await userSessionsDao.getUserSessions(input.sessionId);
    return sessionMembers;
  }),
  getSessionMembersWithMessages: protectedProcedure.input(getSessionMembersDTO).query(async ({ input }) => {
    const userSessionsDao = servicesContainer.get(UserSessionsDao);
    const sessionMembersWithMessages = userSessionsDao.getUserSessionsWithMessages(input.sessionId);
    return sessionMembersWithMessages;
  }),
  getSessionRole: protectedProcedure.input(getSessionRoleDTO).query(async ({ input, ctx }) => {
    const sessionService = servicesContainer.get(SessionService);
    const isOwner = await sessionService.isSessionOwner({ sessionId: input.sessionId, userId: ctx.user.id });
    return isOwner ? UserSessionRole.ADMIN : UserSessionRole.MEMBER;
  }),
});