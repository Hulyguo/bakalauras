import superjson from 'superjson';
import { initTRPC, TRPCError } from '@trpc/server';
import { Context } from '../context';
import { servicesContainer } from '../inversify.config';
import { CryptographyService } from '../services/CryptographyService';
import { IContext } from './types';

const t = initTRPC.context<Context>().create({
  transformer: superjson,
});

const cryptographyService = servicesContainer.get(CryptographyService);

const verifyCsrf = (ctx: IContext) => {
  const csrfSecret = ctx.req.cookies?._csrf as string;
  const csrfToken = ctx.req.headers?.['csrf-token'] as string;
  cryptographyService.verifyCsrfToken(csrfSecret, csrfToken);
};

const isAuthed = t.middleware((opts) => {
  const { ctx } = opts;
  verifyCsrf(ctx);

  if (!ctx.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  return opts.next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});

export const { router } = t;

export const publicProcedure = t.procedure;

export const protectedProcedure = t.procedure.use(isAuthed);