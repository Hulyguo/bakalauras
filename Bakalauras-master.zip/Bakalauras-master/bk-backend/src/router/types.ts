import { FastifyCookieOptions } from "@fastify/cookie";
import { FastifyReply, FastifyRequest } from "fastify";

export interface IContext extends Record<string, unknown> {
  req: FastifyRequest;
  res: FastifyReply;
  user?: any;
}

export interface ExtendedIContext extends IContext {
  req: FastifyRequest & {
    setCookie: (sessionToken: string, randomHash: string, cookieOpts: FastifyCookieOptions) => void;
  };
}