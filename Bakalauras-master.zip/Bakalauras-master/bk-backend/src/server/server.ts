import "reflect-metadata";

import { fastifyTRPCPlugin } from '@trpc/server/adapters/fastify';
import fastify, { FastifyInstance } from 'fastify';
import { createContext } from '../context';
import { appRouter } from '../router/router';
import ws from '@fastify/websocket';
import cors from '@fastify/cors'
import fastifyCookie from "@fastify/cookie";
import { env } from "process";

export interface ServerControl {
  server: FastifyInstance;
  start: () => Promise<void>;
  stop: () => Promise<undefined>;
}

export const createServer = (): ServerControl => {
  const { COOKIE_SECRET } = env;
  const server = fastify({
    maxParamLength: 5000,
    logger: true
  });

  server.register(ws);

  server.register(fastifyTRPCPlugin, {
    prefix: '/trpc',
    trpcOptions: { router: appRouter, createContext },
    useWSS: true,
  });

  server.register(cors, {
    origin: (_, cb) => {
      cb(null, true);
    },
    credentials: true
  });

  server.register(fastifyCookie, {
    secret: COOKIE_SECRET,
  });

  const stop = async (): Promise<undefined> => server.close();
  const start = async (): Promise<void> => {
    try {
      const address = await server.listen({ port: 3000, host: '0.0.0.0' });
      console.log(`Fastify running on ${address}`);

    } catch (err) {
      server.log.error(err);
      process.exit(1);
    }
  };

  return { server, start, stop };
}


