import { inject, injectable } from 'inversify';
import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { CryptographyService } from './CryptographyService';
import { PrismaClientService } from './PrismaClientService';
import { RedisClientService } from './RedisClient';
import { registerDTO } from '../dtos/AuthenticationDTO';


@injectable()
export class AuthenticationService {
  @inject(CryptographyService) private cryptographyService: CryptographyService;
  @inject(PrismaClientService) private prismaClientService: PrismaClientService;
  @inject(RedisClientService) private redisService: RedisClientService;

  public async register(params: z.infer<typeof registerDTO>) {
    const salt = this.cryptographyService.generateRandomHash(8);
    const { password, ...rest } = params;
    const hashedPassword = this.cryptographyService.hash(password, salt);

    await this.prismaClientService.user.create({
      data: { hashedPassword, salt, ...rest },
    });
  }

  public async login(username: string, password: string) {
    const user = await this.prismaClientService.user.findFirst({ where: { username } });
    if (!user) {
      throw new TRPCError({
        code: 'UNAUTHORIZED',
        message: "Invalid credentials",
      });
    }

    const passwordMatch = this.cryptographyService.compare(password, user.hashedPassword, user.salt);
    if (!passwordMatch) {
      throw new TRPCError({
        code: 'UNAUTHORIZED',
        message: "Invalid credentials",
      });
    }

    const randomHash = this.cryptographyService.generateRandomHash(20);
    const { csrfToken, csrfSecret } = this.cryptographyService.generateCsrfTokenAndSecret();
    await this.redisService.setRecord(randomHash, user.id.toString(), process.env?.USER_SESSION_TOKEN_EXPIRE as string);

    return { csrfToken, csrfSecret, randomHash };
  }
}
