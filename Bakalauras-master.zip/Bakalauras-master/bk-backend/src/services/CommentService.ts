import { inject, injectable } from 'inversify';
import { CommentThreadDao } from '../daos/CommentThreadDao';

@injectable()
export class CommentService {
  @inject(CommentThreadDao) private commentThreadDao: CommentThreadDao;

  public async getCommentThreads({ documentId }: { documentId: string }) {
    const commentThreads = await this.commentThreadDao.getCommentThreads({ documentId });
    return commentThreads;
  }
}
