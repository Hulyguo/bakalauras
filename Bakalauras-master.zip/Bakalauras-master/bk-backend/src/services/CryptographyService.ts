import { injectable } from 'inversify';
import crypto from 'crypto';
import CSRFTokens from '@fastify/csrf';
import { TRPCError } from '@trpc/server';

@injectable()
export class CryptographyService {
  private csrfTokens;

  constructor() {
    this.csrfTokens = new CSRFTokens({ userInfo: false });
  }

  public hash(plainString: string, salt?: string) {
    let hashSalt = salt;
    if (!hashSalt) {
      hashSalt = this.generateRandomHash(8);
    }

    return crypto.pbkdf2Sync(plainString, hashSalt, 1000, 32, 'sha512').toString('hex');
  }

  public compare(plainString: string, hashedString: string, salt: string) {
    const hash = crypto.pbkdf2Sync(plainString, salt, 1000, 32, `sha512`).toString(`hex`);
    return hash === hashedString;
  }

  public generateRandomHash(length: number) {
    return crypto.randomBytes(length).toString('hex');
  }

  public generateCsrfTokenAndSecret() {
    const csrfSecret = this.csrfTokens.secretSync();
    const csrfToken = this.csrfTokens.create(csrfSecret);

    return { csrfToken, csrfSecret };
  }

  public verifyCsrfToken(secret?: string, token?: string) {
    if (!secret || !token) {
      throw new TRPCError({ code: 'UNAUTHORIZED' });
    }

    const isValid = this.csrfTokens.verify(secret, token);
    if (!isValid) {
      throw new TRPCError({ code: 'UNAUTHORIZED' });
    }
  }
}
