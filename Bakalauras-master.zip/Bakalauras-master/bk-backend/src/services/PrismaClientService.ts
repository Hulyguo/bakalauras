import { injectable } from 'inversify';
import { PrismaClient } from '@prisma/client';

@injectable()
export class PrismaClientService extends PrismaClient {
  constructor() {
    super({ datasources: { db: { url: 'postgresql://postgres:pass@localhost:5432/bk?schema=public' } } });
  }
}
