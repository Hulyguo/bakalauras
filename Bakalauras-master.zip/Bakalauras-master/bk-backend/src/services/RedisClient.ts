import { injectable } from 'inversify';
import Redis from 'ioredis';

type AddMemberToHsetPayload = {
  hashKey: string;
  memberKey: string;
  memberValue: string;
};

type AddMemberToZsetPayload = {
  zsetKey: string;
  memberKey: string;
  memberScore: number;
};

@injectable()
export class RedisClientService extends Redis {
  constructor() {
    super(process.env.REDIS_URL!, { connectTimeout: 30000 });

    this.on('error', (error: unknown) => console.error(error));
  }

  public checkIfExistsInHset(key: string, memberKey: string) {
    return this.hexists(key, memberKey);
  }

  public async checkIfSetHasMembers(key: string) {
    const membersCount = await this.scard(key);
    return !!membersCount;
  }

  public addMemberToHset({ hashKey, memberKey, memberValue }: AddMemberToHsetPayload) {
    return this.hset(hashKey, memberKey, memberValue);
  }

  public addMemberToSet(key: string, member: string) {
    return this.sadd(key, member);
  }

  public addMembersToSet(key: string, members: string[]) {
    return this.sadd(key, members);
  }

  public addMemberToZset({ zsetKey, memberKey, memberScore }: AddMemberToZsetPayload) {
    return this.zadd(zsetKey, memberScore, memberKey);
  }

  public removeMemberFromHset(key: string, memberKey: string) {
    return this.hdel(key, memberKey);
  }

  public removeMemberFromSet(key: string, member: string) {
    return this.srem(key, member);
  }

  public removeMemberFromZset(key: string, memberId: string) {
    return this.zrem(key, memberId);
  }

  public retrieveSetMembers(setKey: string) {
    return this.smembers(setKey);
  }

  public runMultipleCommands(commands: string[][]) {
    return this.multi(commands).exec();
  }

  public setRecord(key: string, value: string, ttl: string) {
    return this.set(key, value, 'PX', ttl);
  }

  public retrieveRecord(key: string) {
    return this.get(key);
  }

  public deleteRecord(key: string) {
    return this.del(key);
  }

  public async getHsetValue(hashKey: string, memberKey: string) {
    const value = await this.hget(hashKey, memberKey);
    try {
      return JSON.parse(value as string);
    } catch (e) {
      return value;
    }
  }

  public async getZsetMemberScore(zsetKey: string, memberKey: string) {
    return this.zscore(zsetKey, memberKey);
  }

  public disconnectClient() {
    return this.disconnect(false);
  }

  public flushDatabase() {
    return this.flushall();
  }

  public checkHealth() {
    return [this.status === 'ready'];
  }
}
