import { injectable } from 'inversify';


@injectable()
export class SessionMembersService {

}
