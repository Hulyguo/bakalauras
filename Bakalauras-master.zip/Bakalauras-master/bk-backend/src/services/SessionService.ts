import { inject, injectable } from 'inversify';
import {  UserSessionRole } from '@prisma/client';
import { z } from 'zod';
import { getSessionRoleDTO, joinSessionDTO } from '../dtos/SessionDTO';
import { SessionDao } from '../daos/SessionDao';
import { SessionDocumentDao } from '../daos/SessionDocumentDao';
import { UserSessionsDao } from '../daos/UserSessionsDao';
import { sessionEe } from '../router/routers/sessionRouter';

@injectable()
export class SessionService {
  @inject(UserSessionsDao) private userSessionsDao: UserSessionsDao;
  @inject(SessionDao) private sessionDao: SessionDao;
  @inject(SessionDocumentDao) private sessionDocumentDao: SessionDocumentDao;

  public async joinSession({ sessionId, userId }: z.infer<typeof joinSessionDTO> & { userId: string }) {
    const user = await this.userSessionsDao.find({ sessionId, userId });
    if (user) {
      sessionEe.emit('joinSession', user);
      return user;
    }

    const addedSessionMember = await this.userSessionsDao.addUserSessions(sessionId, userId);
    sessionEe.emit('joinSession', addedSessionMember);
    return addedSessionMember;
  }

  public async isSessionOwner({ sessionId, userId }: z.infer<typeof getSessionRoleDTO> & { userId: string }) {
    const session = await this.sessionDao.findUserSessionByUserId({ sessionId, userId });
    if (!session) return false;

    return session.role === "ADMIN";
  }

  public async initializeSessionDocuments(sessionId: string) {
    const sessionMembers = await this.userSessionsDao.getUserSessions(sessionId);
    const memberUserSessions = sessionMembers.filter(userSession => userSession.role !== UserSessionRole.ADMIN);
    const memberUserSessionIds = memberUserSessions.map(sessionMember => sessionMember.userSessionId);
    await this.sessionDocumentDao.createSessionDocuments({ userSessionIds: memberUserSessionIds, sessionId });
  }
}
