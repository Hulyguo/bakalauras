import { OriginFunction } from '@fastify/cors';

export const handleCors: OriginFunction = (_, cb) => {
  cb(null, true);
};
