import { test, expect } from "@playwright/test";

test("Should register a new user", async ({ page }) => {
  await page.goto("http://localhost:5173/register");

  await expect(page.getByText("Sign up")).toBeVisible();

  const usernameField = page.getByPlaceholder("Username", { exact: true });
  const nameField = page.getByPlaceholder("Name", { exact: true });
  const surnameField = page.getByPlaceholder("Surname", { exact: true });
  const passwordField = page.getByPlaceholder("Password", { exact: true });
  const repeatPasswordField = page.getByPlaceholder("Repeat password", {
    exact: true,
  });
  const emailField = page.getByPlaceholder("Email", { exact: true });
  const signUpButton = page.getByText("Sign up", { exact: true });

  await usernameField.fill(`User${Math.random()}`);
  await nameField.fill("Name");
  await surnameField.fill("Surname");
  await passwordField.fill("Password12345!");
  await repeatPasswordField.fill("Password12345!");
  await emailField.fill(`email${Math.random()}@testingteststawfadfawdf.com`);
  signUpButton.click();

  await expect(page.getByText("Login")).toBeVisible();
});

test("Should login existing user.", async ({ page }) => {
  await page.goto("http://localhost:5173/login");

  const loginButton = page.getByText("Login");
  const usernameField = page.getByPlaceholder("Username");
  const passwordField = page.getByPlaceholder("Password");

  await expect(loginButton).toBeVisible();

  await usernameField.fill("AAA");
  await passwordField.fill("Gama1212!");

  loginButton.click();

  await expect(page.getByText("Logout")).toBeVisible();
});

test("Should be able to create and join a session", async ({ page }) => {
  await page.goto("http://localhost:5173/login");

  const loginButton = page.getByText("Login");
  const usernameField = page.getByPlaceholder("Username");
  const passwordField = page.getByPlaceholder("Password");

  await expect(loginButton).toBeVisible();

  await usernameField.fill("AAA");
  await passwordField.fill("Gama1212!");

  loginButton.click();

  await expect(page.getByText("Logout")).toBeVisible();
  await expect(page.getByText("Begin new session")).toBeVisible();

  const newSessionButton = page.getByText("Begin new session");
  newSessionButton.click();

  const sessionNameField = page.getByPlaceholder("Session name");
  await expect(sessionNameField).toBeVisible();
  await sessionNameField.fill("Session name");

  const initializeButton = page.getByText("Initialize session");
  initializeButton.click();
  await expect(page.getByText("Session Lobby")).toBeVisible();

  const beginSessionButton = page.getByText("Begin session");
  const sessionIdSelector = page.getByText("Session Id");
  const sessionId = (await sessionIdSelector.allInnerTexts())[0].split(" ")[2];
  beginSessionButton.click();

  await expect(page.getByText("Cannot start session")).toBeVisible();

  const logoutButton = page.getByText("Logout");
  logoutButton.click();

  await expect(page.getByText("Login")).toBeVisible();
  await usernameField.fill("AAAA");
  await passwordField.fill("Gama1212!");
  loginButton.click();
  await expect(page.getByText("Logout")).toBeVisible();
  const joinSessionButton = page.getByText("Join existing session");

  await expect(joinSessionButton).toBeVisible();
  joinSessionButton.click();
  const sessionIdField = page.getByText("Session ID");
  await sessionIdField.fill(sessionId);
  const joinActualSession = page.getByText("Join session");
  joinActualSession.click();
  await expect(page.getByText("Session Lobby")).toBeVisible();

  logoutButton.click();
  await expect(loginButton).toBeVisible();
  await usernameField.fill("AAA");
  await passwordField.fill("Gama1212!");

  loginButton.click();
  joinSessionButton.click();
  await sessionIdField.fill(sessionId);
  joinActualSession.click();
  await expect(beginSessionButton).toBeVisible();
});
