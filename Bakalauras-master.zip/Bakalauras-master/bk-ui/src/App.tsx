import { useMemo, useState } from "react";

// TypeScript users only add this code
import { BaseEditor } from "slate";
import { ReactEditor } from "slate-react";
import { RouterProvider } from "react-router-dom";
import { router } from "./router/router";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { createClient, trpc } from "./utils/trpc";
import { useCookies } from "react-cookie";

type CustomElement = { type: "paragraph"; children: CustomText[] };
type CustomText = { text: string };

declare module "slate" {
  interface CustomTypes {
    Editor: BaseEditor & ReactEditor;
    Element: CustomElement;
    Text: CustomText;
  }
}

import styles from "./app.module.scss";
import classNames from "classnames/bind";
import { AUTHENTICATION_COOKIE } from "./utils/constants";

const cx = classNames.bind(styles);

const App: React.FC = () => {
  const [cookies] = useCookies();
  const [queryClient] = useState(() => new QueryClient());
  const trpcClient = useMemo(
    () => createClient(cookies[AUTHENTICATION_COOKIE]),
    [cookies[AUTHENTICATION_COOKIE]],
  );

  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <div className={cx("app")}>
          <RouterProvider router={router} />
        </div>
      </QueryClientProvider>
    </trpc.Provider>
  );
};

export default App;
