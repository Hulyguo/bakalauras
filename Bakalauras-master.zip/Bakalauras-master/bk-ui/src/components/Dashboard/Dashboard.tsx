import styles from "./dashboard.module.scss";
import classNames from "classnames/bind";
import { Button } from "primereact/button";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { Avatar } from "primereact/avatar";

const cx = classNames.bind(styles);

export const Dashboard: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const shouldHideSidebar =
    location.pathname.includes("session-admin") ||
    location.pathname.includes("session-user");

  const handleLogout = () => {
    navigate("/logout");
  };

  return (
    <div className={cx("dashboard")}>
      {!shouldHideSidebar && (
        <div className={cx("dashboard__sidebar")}>
          <div className={cx("dashboard__title")}>
            <Avatar
              label="P"
              size="large"
              style={{ backgroundColor: "#2196F3", color: "#ffffff" }}
            />
            <Button
              className="cursor-pointer ml-auto"
              icon="pi pi-sign-out"
              onClick={handleLogout}
              severity="secondary"
            >
              <span className="ml-2">Logout</span>
            </Button>
          </div>
          {/* <Button onClick={() => navigate('student-home')} label="Dashboard" className="w-full mb-2" /> */}
          <Button
            onClick={() => navigate("initialize-session")}
            label="Begin new session"
            className="w-full"
          />
          <Button
            onClick={() => navigate("join-session")}
            label="Join existing session"
            className="w-full mt-2"
          />
          <Button
            label="My sessions"
            onClick={() => navigate("user-sessions")}
            className="w-full mt-2"
          ></Button>
        </div>
      )}
      <div className={cx("dashboard__content")}>
        <Outlet />
      </div>
    </div>
  );
};
