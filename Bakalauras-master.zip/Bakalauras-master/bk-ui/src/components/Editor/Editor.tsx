import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import isHotkey from "is-hotkey";
import { Editable, withReact, useSlate, Slate, useFocused } from "slate-react";
import {
  Editor,
  Transforms,
  createEditor,
  Descendant,
  Element as SlateElement,
  Range,
  Operation,
  BaseOperation,
} from "slate";
import { withHistory } from "slate-history";
import StyledText from "./components/StyledText";

import { Button, Icon, Portal, Toolbar } from "./components";
import { DebouncedFunc } from "lodash";
import {
  getMarkForCommentThreadID,
  insertCommentThread,
  shouldAllowNewCommentThreadAtSelection,
} from "./utils/EditorCommentUtils";
import { useEditorCommentContext } from "./providers/EditorCommentsProvider";
import { CommentThreadPopover } from "./components/CommentThreadPopover/CommentThreadPopover";
import { ProgressSpinner } from "primereact/progressspinner";
import { CommentsSidebar } from "./components/CommentSidebar/CommentSidebar";

import classNames from "classnames/bind";
import styles from "./editor.module.scss";
import { SidebarView } from "components/TeacherView/TeacherView";
import { trpc } from "utils/trpc";
import { useParams } from "react-router-dom";
import { SessionStatus } from "types/enums";

const cx = classNames.bind(styles);

const HOTKEYS = {
  "mod+b": "bold",
  "mod+i": "italic",
  "mod+u": "underline",
  "mod+`": "code",
};

const LIST_TYPES = ["numbered-list", "bulleted-list"];
const TEXT_ALIGN_TYPES = ["left", "center", "right", "justify"];

const isBlockActive = (editor, format, blockType = "type") => {
  const { selection } = editor;
  if (!selection) return false;

  const [match] = Array.from(
    Editor.nodes(editor, {
      at: Editor.unhangRange(editor, selection),
      match: (n) =>
        !Editor.isEditor(n) &&
        SlateElement.isElement(n) &&
        n[blockType] === format,
    })
  );

  return !!match;
};

const toggleBlock = (editor, format) => {
  const isActive = isBlockActive(
    editor,
    format,
    TEXT_ALIGN_TYPES.includes(format) ? "align" : "type"
  );
  const isList = LIST_TYPES.includes(format);

  Transforms.unwrapNodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) &&
      SlateElement.isElement(n) &&
      LIST_TYPES.includes(n.type) &&
      !TEXT_ALIGN_TYPES.includes(format),
    split: true,
  });
  let newProperties: Partial<SlateElement>;
  if (TEXT_ALIGN_TYPES.includes(format)) {
    newProperties = {
      align: isActive ? undefined : format,
    };
  } else {
    if (isActive) {
      newProperties = { type: "paragraph" };
    } else {
      newProperties = { type: isList ? "list-item" : format };
    }
  }
  Transforms.setNodes<SlateElement>(editor, newProperties);

  if (!isActive && isList) {
    const block = { type: format, children: [] };
    Transforms.wrapNodes(editor, block);
  }
};

const isMarkActive = (editor, format) => {
  const marks = Editor.marks(editor);
  return marks ? marks[format] === true : false;
};

const toggleMark = (editor, format) => {
  const isActive = isMarkActive(editor, format);

  if (isActive) {
    Editor.removeMark(editor, format);
  } else {
    editor.addMark(format, true);
  }
};

const Element = ({ attributes, children, element }) => {
  const style = { textAlign: element.align };
  switch (element.type) {
    case "block-quote":
      return (
        <blockquote style={style} {...attributes}>
          {children}
        </blockquote>
      );
    case "bulleted-list":
      return (
        <ul style={style} {...attributes}>
          {children}
        </ul>
      );
    case "heading-one":
      return (
        <h1 style={style} {...attributes}>
          {children}
        </h1>
      );
    case "heading-two":
      return (
        <h2 style={style} {...attributes}>
          {children}
        </h2>
      );
    case "list-item":
      return (
        <li style={style} {...attributes}>
          {children}
        </li>
      );
    case "numbered-list":
      return (
        <ol style={style} {...attributes}>
          {children}
        </ol>
      );
    default:
      return (
        <p style={style} {...attributes}>
          {children}
        </p>
      );
  }
};

const Leaf = ({ attributes, children, leaf }) => {
  if (leaf.bold) {
    children = <strong>{children}</strong>;
  }

  if (leaf.code) {
    children = <code>{children}</code>;
  }

  if (leaf.italic) {
    children = <em>{children}</em>;
  }

  if (leaf.underline) {
    children = <u>{children}</u>;
  }

  return (
    <StyledText attributes={attributes} leaf={leaf}>
      {children}
    </StyledText>
  );
};

const CommentButton = () => {
  const editor = useSlate();
  const { addCommentThread } = useEditorCommentContext();

  const onInsertComment = useCallback(() => {
    insertCommentThread(editor, addCommentThread);
  }, [editor]);

  const selection = editor.selection;

  return (
    <Button
      onMouseDown={onInsertComment}
      disabled={!shouldAllowNewCommentThreadAtSelection(editor, selection)}
    >
      <Icon>{"comment"}</Icon>
    </Button>
  );
};

const HoveringToolbar = () => {
  const ref = useRef<HTMLDivElement | null>();
  const editor = useSlate();
  const inFocus = useFocused();

  useEffect(() => {
    const el = ref.current;
    const { selection } = editor;

    if (!el) {
      return;
    }

    if (
      !selection ||
      !inFocus ||
      Range.isCollapsed(selection) ||
      Editor.string(editor, selection) === ""
    ) {
      el.removeAttribute("style");
      return;
    }

    const domSelection = window.getSelection();
    const domRange = domSelection!.getRangeAt(0);
    const rect = domRange.getBoundingClientRect();
    el.style.opacity = "1";
    el.style.top = `${rect.top + window.scrollY - el.offsetHeight}px`;
    el.style.position = "absolute";
    el.style.background = "#000";
    el.style.borderRadius = "0.5rem";
    el.style.padding = "0.5rem";
    el.style.left = `${
      rect.left + window.scrollX - el.offsetWidth / 2 + rect.width / 2
    }px`;
  });

  return <Portal></Portal>;
};

const BlockButton = ({ format, icon }) => {
  const editor = useSlate();
  return (
    <Button
      active={isBlockActive(
        editor,
        format,
        TEXT_ALIGN_TYPES.includes(format) ? "align" : "type"
      )}
      onMouseDown={(event) => {
        event.preventDefault();
        toggleBlock(editor, format);
      }}
    >
      <Icon>{icon}</Icon>
    </Button>
  );
};

const MarkButton = ({ format, icon }) => {
  const editor = useSlate();
  return (
    <Button
      active={isMarkActive(editor, format)}
      onMouseDown={(event: MouseEvent) => {
        event.preventDefault();
        toggleMark(editor, format);
      }}
    >
      <Icon>{icon}</Icon>
    </Button>
  );
};

interface SlateEditorProps {
  document: Descendant[];
  selectedView?: SidebarView;
  onChange?: DebouncedFunc<
    (value: Descendant[], operations: BaseOperation[]) => void
  >;
  isTeacher?: boolean;
  sessionStatus?: SessionStatus;
  savedOperations?: {
    id: number;
    operations: BaseOperation[];
    sessionDocumentId: string;
    userId: string;
  }[];
}

export const SlateEditor: React.FC<SlateEditorProps> = ({
  document,
  onChange,
  selectedView,
  savedOperations,
  sessionStatus,
  isTeacher = false,
}) => {
  const [operationIndex, setOperationIndex] = useState<null | number>(null);
  const editorRef = useRef<any>(null);
  const { documentId } = useParams() as { documentId: string };
  const editor = useMemo(() => withHistory(withReact(createEditor())), []);
  const isTeacherReadonly =
    isTeacher && sessionStatus === SessionStatus.Finalized;
  const isStudentReadonly =
    !isTeacher && sessionStatus === SessionStatus.Finalized;

  const { activeCommentThreadId, areThreadsLoaded } = useEditorCommentContext();
  const renderElement = useCallback((props: any) => <Element {...props} />, []);
  const renderLeaf = (props: any) => <Leaf {...props} />;
  const [unsentOperations, setUnsentOperations] = useState<BaseOperation[]>([]);

  const allSavedOperations = savedOperations?.flatMap((op) => op.operations);

  const tryout = () => {
    if (operationIndex === 0) {
      return;
    }

    setOperationIndex((prev) => {
      const opToApply = Operation.inverse(
        allSavedOperations[prev ? prev - 1 : allSavedOperations?.length - 1]
      );
      try {
        editor.apply(opToApply);
      } catch (e) {
        console.log({ e });
      }
      return prev ? prev - 1 : allSavedOperations?.length - 1;
    });
  };

  const tryoutBack = () => {
    if (operationIndex === allSavedOperations?.length) {
      return;
    }

    const opToApply =
      allSavedOperations[operationIndex ?? allSavedOperations?.length - 1];
    editor.apply(opToApply);
    setOperationIndex((prev) => {
      return prev != null ? prev + 1 : allSavedOperations?.length - 1;
    });
  };

  useEffect(() => {
    const onArrowDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") {
        tryout();
      }
      if (event.key === "ArrowRight") {
        tryoutBack();
      }
    };

    window.addEventListener("keydown", onArrowDown);
    return () => {
      window.removeEventListener("keydown", onArrowDown);
    };
  }, [allSavedOperations, tryout, tryoutBack]);

  trpc.comment.onAddCommentThread.useSubscription(
    { documentId },
    {
      onData: (data: any) => {
        editor.addMark(getMarkForCommentThreadID(data.id), true);
      },
    }
  );

  const editorOffsets =
    editorRef.current != null
      ? {
          x: editorRef.current.getBoundingClientRect().x,
          y: editorRef.current.getBoundingClientRect().y,
        }
      : null;

  if (!areThreadsLoaded) return <ProgressSpinner />;

  return (
    <Slate
      editor={editor}
      value={document} 
      onChange={(value) => {
        const { operations } = editor;
        if (sessionStatus === SessionStatus.Finalized) return;

        const isAstChange = operations.some(
          (op) => "set_selection" !== op.type
        );

        if (!isAstChange) {
          return;
        }

        const operationsToSend = [...unsentOperations, ...operations];

        onChange && onChange(value, operationsToSend);

        setUnsentOperations(operationsToSend);
      }}
    >
      <div className={cx("editor__container")}>
        <CommentsSidebar selectedView={selectedView} />
        <Toolbar>
          {!isStudentReadonly && !isTeacher && (
            <>
              <MarkButton format="bold" icon="format_bold" />
              <MarkButton format="italic" icon="format_italic" />
              <MarkButton format="underline" icon="format_underlined" />
              <MarkButton format="code" icon="code" />
              <BlockButton format="heading-one" icon="looks_one" />
              <BlockButton format="heading-two" icon="looks_two" />
              <BlockButton format="block-quote" icon="format_quote" />
              <BlockButton format="numbered-list" icon="format_list_numbered" />
              <BlockButton format="bulleted-list" icon="format_list_bulleted" />
              <BlockButton format="left" icon="format_align_left" />
              <BlockButton format="center" icon="format_align_center" />
              <BlockButton format="right" icon="format_align_right" />
              <BlockButton format="justify" icon="format_align_justify" />
            </>
          )}
          {isTeacher && <CommentButton />}
          {isTeacherReadonly && <Button onClick={tryout}>Backward</Button>}
          {isTeacherReadonly && <Button onClick={tryoutBack}>Forward</Button>}
          {isTeacherReadonly && (
            <div>
              OP: {operationIndex ?? allSavedOperations?.length}/
              {allSavedOperations?.length}
            </div>
          )}
        </Toolbar>
        <div style={{ position: "relative" }} ref={editorRef}>
          {activeCommentThreadId != null && editorOffsets ? (
            <CommentThreadPopover
              editorOffsets={editorOffsets}
              selection={editor.selection}
              threadId={activeCommentThreadId}
            />
          ) : null}
          <HoveringToolbar />
          <Editable
            className={cx("editor")}
            readOnly={isTeacher || sessionStatus === SessionStatus.Finalized}
            renderElement={renderElement}
            renderLeaf={renderLeaf}
            spellCheck
            autoFocus
            onKeyDown={(event) => {
              for (const hotkey in HOTKEYS) {
                if (isHotkey(hotkey, event as any) && !isTeacher) {
                  event.preventDefault();
                  const mark = HOTKEYS[hotkey];
                  toggleMark(editor, mark);
                }
              }
            }}
          />
        </div>
      </div>
    </Slate>
  );
};
