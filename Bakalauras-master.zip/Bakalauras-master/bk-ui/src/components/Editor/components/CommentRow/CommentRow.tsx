import { format } from "date-fns";
import { Comment } from "components/Editor/utils/EditorCommentUtils";

import styles from "./comment-row.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

interface CommentRowProps {
  comment: Comment;
}

export const CommentRow: React.FC<CommentRowProps> = ({ comment }) => {
  if (!comment) return null;

  return (
    <div className={cx("comment-row")}>
      <div className="comment-row__author-photo">
        <i className="bi bi-person-circle comment-author-photo"></i>
      </div>
      <div className={cx("comment-row__details")}>
        <span className={cx("comment-row__author-name")}>
          {comment.author?.firstName} {comment.author?.lastName}
        </span>
        <div className={cx("comment-row__info")}>
          <div className={cx("comment-row__text")}>{comment.text}</div>
          <span className={cx("comment-row__creation-time")}>
            {format(new Date(comment.creationTime), "eee MM/dd H:mm")}
          </span>
        </div>
      </div>
    </div>
  );
};
