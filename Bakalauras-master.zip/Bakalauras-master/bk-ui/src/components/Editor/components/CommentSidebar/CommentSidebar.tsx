import { useEditorCommentContext } from "components/Editor/providers/EditorCommentsProvider";
import { CommentThread } from "components/Editor/components/CommentThread/CommentThread";

import ReactDOM from "react-dom";
import { useEffect, useState } from "react";
import { SidebarView } from "components/TeacherView/TeacherView";

import styles from "./comment-sidebar.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

interface CommentsSidebarProps {
  selectedView?: SidebarView;
}

export const CommentsSidebar: React.FC<CommentsSidebarProps> = ({
  selectedView,
}) => {
  const [sidebarContentEl, setSidebarContentEl] = useState<Element | null>(
    null,
  );
  const { commentThreadIds } = useEditorCommentContext();

  useEffect(() => {
    const el = document.querySelector("#comment-sidebar");
    el && setSidebarContentEl(el);

    return () => {
      setSidebarContentEl(null);
    };
  }, []);

  if (!sidebarContentEl) return null;
  if (selectedView === SidebarView.Messages) return null;

  return ReactDOM.createPortal(
    <div className={cx("comment-sidebar")}>
      <div className={cx("comment-sidebar__title")}>Comments</div>
      <div>
        {Array.from(commentThreadIds).map((id) => (
          <div key={id}>
            <div>
              <CommentThread id={id} />
            </div>
          </div>
        ))}
      </div>
    </div>,
    sidebarContentEl,
  );
};
