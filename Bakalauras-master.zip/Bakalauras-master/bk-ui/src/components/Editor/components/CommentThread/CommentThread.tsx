import { useEditorCommentContext } from "components/Editor/providers/EditorCommentsProvider";
import { useState, useCallback, useRef } from "react";
import { Button } from "primereact/button";
import { CommentRow } from "components/Editor/components/CommentRow/CommentRow";
import { Editor, Path, Text, Transforms } from "slate";
import { getCommentThreadsOnTextNode } from "components/Editor/utils/EditorCommentUtils";
import { useSlate } from "slate-react";

import classNames from "classnames/bind";
import styles from "./comment-thread.module.scss";
import { Toast } from "primereact/toast";
import { CommentThreadStatus } from "types/enums";

const cx = classNames.bind(styles);

interface CommentThreadProps {
  id: string;
}

export const CommentThread: React.FC<CommentThreadProps> = ({ id }) => {
  const toastRef = useRef<Toast | null>(null);
  const { commentThreads, activeCommentThreadId, setActiveCommentThreadId } =
    useEditorCommentContext();
  const commentThread = commentThreads[id];
  const status = commentThreads[id].status;
  const editor = useSlate();

  const [shouldShowReplies, setShouldShowReplies] = useState(false);
  const onBtnClick = useCallback(
    (e: MouseEvent) => {
      e.stopPropagation();
      setShouldShowReplies(!shouldShowReplies);
    },
    [shouldShowReplies, setShouldShowReplies],
  );

  const onClick = useCallback(() => {
    if (!id) return;
    const textNodesWithThread = Editor.nodes(editor, {
      at: [],
      mode: "lowest",
      match: (n) => Text.isText(n) && getCommentThreadsOnTextNode(n).has(id),
    });

    let textNodeEntry = textNodesWithThread.next().value;
    const allTextNodePaths = [];

    while (textNodeEntry != null) {
      allTextNodePaths.push(textNodeEntry[1]);
      textNodeEntry = textNodesWithThread.next().value;
    }

    allTextNodePaths.sort((p1, p2) => Path.compare(p1, p2));

    if (!allTextNodePaths.length) {
      toastRef.current?.show({
        summary: "Commented text deleted in editor",
        severity: "info",
      });
      return;
    }

    Transforms.select(editor, {
      anchor: Editor.point(editor, [8, 0], { edge: "start" }),
      focus: Editor.point(
        editor,
        allTextNodePaths[allTextNodePaths.length - 1],
        { edge: "end" },
      ),
    });

    setActiveCommentThreadId(id);
  }, [editor, id, setActiveCommentThreadId]);

  if (commentThread.comments?.length === 0) {
    return null;
  }

  const [firstComment, ...otherComments] = commentThread.comments ?? [];

  return (
    <div
      className={cx("comment-thread", {
        "comment-thread--active": activeCommentThreadId === id,
        "comment-thread--resolved": status === CommentThreadStatus.Resolved,
      })}
      onClick={onClick}
    >
      <Toast ref={toastRef} />
      {firstComment && <CommentRow comment={firstComment} />}
      {shouldShowReplies
        ? otherComments.map((comment) => {
            return (
              <CommentRow
                key={`comment-${comment.creationTime}`}
                comment={comment}
              />
            );
          })
        : null}
      {commentThread.comments?.length > 1 ? (
        <Button
          className={"show-replies-btn"}
          onClick={onBtnClick}
          onKeyDown={(e) => onBtnClick(e as any)}
        >
          {shouldShowReplies ? "Hide Thread" : "Show Thread"}
        </Button>
      ) : null}
    </div>
  );
};
