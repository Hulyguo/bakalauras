import { Selection, Text } from "slate";
import { ReactEditor, useSlate } from "slate-react";
import { getFirstTextNodeAtSelection } from "components/Editor/utils/EditorUtils";
import { useCallback, useState } from "react";
import { useEditorCommentContext } from "components/Editor/providers/EditorCommentsProvider";
import { NodePopover } from "components/Editor/components/NodePopover/NodePopover";
import {
  getCommentThreadsOnTextNode,
  getMarkForCommentThreadID,
} from "components/Editor/utils/EditorCommentUtils";

interface CommentThreadPopoverProps {
  selection: Selection;
  threadId: string;
  editorOffsets: any;
}

import styles from "./comment-thread-popover.module.scss";
import classNames from "classnames/bind";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { CommentRow } from "components/Editor/components/CommentRow/CommentRow";
import { CommentThreadStatus } from "types/enums";

const cx = classNames.bind(styles);

export const CommentThreadPopover: React.FC<CommentThreadPopoverProps> = ({
  editorOffsets,
  selection,
  threadId,
}) => {
  const editor = useSlate();
  const {
    setActiveCommentThreadId,
    addCommentToThread,
    commentThreads,
    updateCommentThreadStatus,
  } = useEditorCommentContext();
  const textNode = getFirstTextNodeAtSelection(editor, selection);
  const [commentText, setCommentText] = useState("");

  const onClickOutside = useCallback(
    (event: any) => {
      const slateDOMNode = event.target.hasAttribute("data-slate-node")
        ? event.target
        : event.target.closest("[data-slate-node]");

      if (slateDOMNode == null) {
        setActiveCommentThreadId(null);
        return;
      }

      const slateNode = ReactEditor.toSlateNode(editor, slateDOMNode);

      if (
        Text.isText(slateNode) &&
        getCommentThreadsOnTextNode(slateNode).size > 0
      ) {
        return;
      }

      setActiveCommentThreadId(null);
    },
    [editor, setActiveCommentThreadId],
  );

  const onToggleStatus = useCallback(() => {
    const currentStatus = commentThreads[threadId].status;
    editor.removeMark(getMarkForCommentThreadID(threadId));
    updateCommentThreadStatus(
      threadId,
      currentStatus === CommentThreadStatus.Open
        ? CommentThreadStatus.Resolved
        : CommentThreadStatus.Open,
    );
  }, [addCommentToThread, commentThreads[threadId].status]);

  const onClick = useCallback(() => {
    addCommentToThread(
      threadId,
      { text: commentText, creationTime: new Date() },
      false,
      true,
    );
    setCommentText("");
  }, [commentText, addCommentToThread]);

  return (
    <NodePopover
      editorOffsets={editorOffsets}
      isBodyFullWidth={true}
      node={textNode}
      className={cx("comment-thread-popover")}
      onClickOutside={onClickOutside}
    >
      <div className={cx("comment-thread-popover__wrapper")}>
        <div>
          {commentThreads[threadId].status != null ? (
            <Button
              className={`p-button-primary ${cx("comment-thread-popover__action")}`}
              onClick={onToggleStatus}
            >
              {commentThreads[threadId].status === CommentThreadStatus.Open
                ? "Resolve"
                : "Re-Open"}
            </Button>
          ) : null}
        </div>
        <form className={cx("comment-thread-popover__form")}>
          <div className={cx("comment-thread-popover__list")}>
            {commentThreads[threadId] &&
              commentThreads[threadId]?.comments?.map((comment) => {
                return (
                  <CommentRow
                    key={comment.creationTime.toString()}
                    comment={comment}
                  />
                );
              })}
          </div>
          <InputText
            className={cx("comment-thread-popover__input")}
            onChange={(e) => setCommentText(e.target.value)}
          />
          <Button
            className="p-button-primary"
            disabled={commentText.length === 0}
            onClick={onClick}
          >
            Comment
          </Button>
        </form>
      </div>
    </NodePopover>
  );
};
