import classNames from "classnames/bind";
import { useSlate } from "slate-react";
import { useEditorCommentContext } from "components/Editor/providers/EditorCommentsProvider";
import { getSmallestCommentThreadAtTextNode } from "components/Editor/utils/EditorCommentUtils";
import styles from "./commented-text.module.scss";

const cx = classNames.bind(styles);

export default function CommentedText(props: any) {
  const editor = useSlate();
  const { textNode, commentThreads, ...otherProps } = props;
  const { activeCommentThreadId, setActiveCommentThreadId } =
    useEditorCommentContext();

  const onMouseDown = () => {
    const thread = getSmallestCommentThreadAtTextNode(editor, textNode);
    setActiveCommentThreadId(thread);
  };

  return (
    <span
      {...otherProps}
      className={cx("comment", {
        "comment--active":
          activeCommentThreadId && commentThreads.has(activeCommentThreadId),
      })}
      onMouseDown={onMouseDown}
    >
      {props.children}
    </span>
  );
}
