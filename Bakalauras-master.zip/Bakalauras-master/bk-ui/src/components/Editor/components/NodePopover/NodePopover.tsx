import { ReactEditor, useSlate } from "slate-react";
import { useCallback, useEffect, useRef } from "react";

interface NodePopoverProps {
  header?: any;
  node: any;
  children: React.ReactNode;
  editorOffsets: any;
  className: string;
  isBodyFullWidth: boolean;
  onClickOutside: any;
}

export const NodePopover: React.FC<NodePopoverProps> = ({
  header,
  node,
  children,
  editorOffsets,
  className,
  isBodyFullWidth,
  onClickOutside,
}) => {
  const popoverRef = useRef<HTMLElement>(null);
  const editor = useSlate();

  useEffect(() => {
    const editorEl = popoverRef.current;
    if (editorEl == null) {
      return;
    }

    if (!node) return;

    const domNode = ReactEditor.toDOMNode(editor, node);
    const {
      x: nodeX,
      height: nodeHeight,
      y: nodeY,
    } = domNode.getBoundingClientRect();

    editorEl.style.display = "block";
    editorEl.style.top = `${nodeY + nodeHeight - editorOffsets.y}px`;
    editorEl.style.left = `${nodeX - editorOffsets.x}px`;
    editorEl.scrollIntoView(false);
  }, [editor, editorOffsets.x, editorOffsets.y, node]);

  const onMouseDown = useCallback(
    (event: MouseEvent) => {
      if (
        popoverRef.current != null &&
        !popoverRef.current.contains(event.target) &&
        onClickOutside != null
      ) {
        onClickOutside(event);
      }
    },
    [onClickOutside],
  );

  useEffect(() => {
    document.addEventListener("mousedown", onMouseDown);

    return () => {
      document.removeEventListener("mousedown", onMouseDown);
    };
  }, [onMouseDown]);

  if (editorOffsets == null) {
    return null;
  }

  return (
    <div ref={popoverRef} className={className}>
      {header != null ? <div>{header}</div> : null}
      <div style={isBodyFullWidth ? { padding: 0 } : undefined}>{children}</div>
    </div>
  );
};
