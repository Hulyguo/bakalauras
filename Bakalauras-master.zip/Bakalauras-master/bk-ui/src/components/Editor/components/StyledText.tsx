import { useEditorCommentContext } from "components/Editor/providers/EditorCommentsProvider";
import { getCommentThreadsOnTextNode } from "components/Editor/utils/EditorCommentUtils";
import CommentedText from "./CommentedText/CommentedText";

export default function StyledText({ attributes, children, leaf }) {
  const { setActiveCommentThreadId } = useEditorCommentContext();
  const commentThreads = getCommentThreadsOnTextNode(leaf);

  if (commentThreads.size > 0) {
    return (
      <CommentedText
        {...attributes}
        commentThreads={commentThreads}
        textNode={leaf}
      >
        {children}
      </CommentedText>
    );
  }

  const onClick = () => {
    setActiveCommentThreadId(null);
  };

  return (
    <span onClick={onClick} onKeyDown={() => null} {...attributes}>
      {children}
    </span>
  );
}
