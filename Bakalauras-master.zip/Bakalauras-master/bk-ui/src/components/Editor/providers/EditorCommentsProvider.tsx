import React, { useContext, useState } from "react";
import { useParams } from "react-router-dom";
import { CommentThreadStatus } from "../../../../../bk-backend/src/types";
import { trpc } from "utils/trpc";
import {
  Comment,
  CommentThread,
} from "components/Editor/utils/EditorCommentUtils";

interface EditorCommentsProviderProps {
  children: React.ReactNode;
}

const EditorCommentContext = React.createContext({});

interface CommentThreadSet {
  [commentThreadId: string]: CommentThread;
}

export const EditorCommentsProvider: React.FC<EditorCommentsProviderProps> = ({
  children,
}) => {
  const { documentId } = useParams() as {
    sessionId: string;
    documentId: string;
  };
  const [commentThreads, setCommentThreads] = useState<CommentThreadSet>({});
  const [commentThreadIds, setCommentThreadIds] = useState<string[]>([]);
  const [activeCommentThreadId, setActiveCommentThreadId] = useState<
    string | null
  >(null);

  const addCommentThreadMutation = trpc.comment.addCommentThread.useMutation();
  const addCommentToThreadMutation =
    trpc.comment.addCommentToThread.useMutation();
  const updateCommentThreadStatusMutation =
    trpc.comment.updateCommentThreadStatus.useMutation();

  const getCommentThreads = trpc.comment.getCommentThreads.useQuery(
    { documentId },
    {
      onSuccess: (res) => {
        const mappedThreads = {};

        res?.forEach((thread) => {
          mappedThreads[thread.id] = thread;
        });
        setCommentThreads(mappedThreads);

        const threadIds = res?.map(({ id }) => id) ?? [];
        setCommentThreadIds(threadIds);
      },
      enabled: !!documentId,
    },
  );

  const addCommentThread = (
    id: string,
    thread: CommentThread,
    skipMutation?: boolean,
  ) => {
    !skipMutation &&
      documentId &&
      addCommentThreadMutation.mutate(
        {
          id: thread.threadId,
          status: thread.status,
          documentId,
        },
        {
          onSuccess: () => null,
        },
      );

    setCommentThreads((prev) => {
      return {
        ...prev,
        [id]: thread,
      };
    });

    setCommentThreadIds((prev) => {
      const a = new Set([...Array.from(prev), id]);
      return a;
    });
  };

  const addCommentToThread = (
    id: string,
    comment: Comment,
    skipMutation?: boolean,
    skipState?: boolean,
  ) => {
    !skipMutation &&
      addCommentToThreadMutation.mutate({
        commentThreadId: id,
        text: comment.text,
      });

    !skipState &&
      setCommentThreads((prev) => {
        return {
          ...prev,
          [id]: {
            ...prev[id],
            comments: [...(prev[id].comments ?? []), comment],
          },
        };
      });
  };

  const updateCommentThreadStatus = (
    id: string,
    status: CommentThreadStatus,
  ) => {
    updateCommentThreadStatusMutation.mutate({
      id,
      status,
    });

    setCommentThreads((prev) => {
      return {
        ...prev,
        [id]: {
          ...prev[id],
          status,
        },
      };
    });
  };

  return (
    <EditorCommentContext.Provider
      value={{
        activeCommentThreadId,
        addCommentThread,
        updateCommentThreadStatus,
        commentThreadIds,
        commentThreads,
        setActiveCommentThreadId,
        addCommentToThread,
        areThreadsLoaded: !getCommentThreads.isLoading,
        refetchCommentThreads: () => getCommentThreads.refetch(),
      }}
    >
      {children}
    </EditorCommentContext.Provider>
  );
};

export interface EditorCommentContextType {
  activeCommentThreadId: string;
  addCommentThread: (
    id: string,
    threadData: CommentThread,
    skipMutation?: boolean,
  ) => void;
  commentThreadIds: string[];
  commentThreads: CommentThreadSet;
  setActiveCommentThreadId: (threadId: string | null) => void;
  addCommentToThread: (
    threadId: string,
    threadData: Comment,
    skipMutation?: boolean,
    skipState?: boolean,
  ) => void;
  areThreadsLoaded: boolean;
  updateCommentThreadStatus: (id: string, status: CommentThreadStatus) => void;
  refetchCommentThreads: () => void;
}

export const useEditorCommentContext = (): EditorCommentContextType =>
  useContext(EditorCommentContext) as EditorCommentContextType;
