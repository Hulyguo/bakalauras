import { Editor, Path, Range, Selection, Text } from "slate";
import { CommentThreadStatus } from "types/enums";
import { v4 as uuidv4 } from "uuid";

const COMMENT_THREAD_PREFIX = "commentThread_";

export function getMarkForCommentThreadID(threadID: string) {
  return `${COMMENT_THREAD_PREFIX}${threadID}`;
}

function isCommentThreadIDMark(mayBeCommentThread: any) {
  return mayBeCommentThread.indexOf(COMMENT_THREAD_PREFIX) === 0;
}

export function getCommentThreadIDFromMark(mark: any) {
  if (!isCommentThreadIDMark(mark)) {
    throw new Error("Expected mark to be of a comment thread");
  }
  return mark.replace(COMMENT_THREAD_PREFIX, "");
}

export function getCommentThreadsOnTextNode(textNode: any) {
  return new Set(
    Object.keys(textNode)
      .filter(isCommentThreadIDMark)
      .map(getCommentThreadIDFromMark),
  );
}

export interface Comment {
  text: string;
  authorId: string;
  creationTime: Date;
}

export interface CommentThread {
  comments: Comment[];
  status: any;
  creationTime: Date;
  threadId: string;
}

function updateCommentThreadLengthMap(
  editor: Editor,
  commentThreads: any,
  nodeIterator: any,
  map: any,
) {
  let nextNodeEntry = nodeIterator(editor);

  while (nextNodeEntry != null) {
    const nextNode = nextNodeEntry[0];
    const commentThreadsOnNextNode = getCommentThreadsOnTextNode(nextNode);

    const intersection = [...commentThreadsOnNextNode].filter((x) =>
      commentThreads.has(x),
    );

    // All comment threads we're looking for have already ended meaning
    // reached an uncommented text node OR a commented text node which
    // has none of the comment threads we care about.
    if (intersection.length === 0) {
      break;
    }

    // update thread lengths for comment threads we did find on this
    // text node.
    for (const i of intersection) {
      map.set(i, map.get(i) + nextNode.text.length);
    }

    // call the iterator to get the next text node to consider
    nextNodeEntry = nodeIterator(editor, nextNodeEntry[1]);
  }

  return map;
}

export function insertCommentThread(
  editor: Editor,
  addCommentThreadToState: (
    threadId: string,
    commentThread: CommentThread,
  ) => void,
) {
  const threadId = uuidv4();
  const newCommentThread = {
    comments: [],
    creationTime: new Date(),
    status: CommentThreadStatus.Open,
    threadId,
  };
  addCommentThreadToState(threadId, newCommentThread);
  editor.addMark(getMarkForCommentThreadID(threadId), true);
  return threadId;
}

export function shouldAllowNewCommentThreadAtSelection(
  editor: Editor,
  selection: Selection,
) {
  if (selection == null || Range.isCollapsed(selection)) {
    return false;
  }

  const textNodeIterator = Editor.nodes(editor, {
    at: selection,
    mode: "lowest",
  });

  let nextTextNodeEntry = textNodeIterator.next().value;
  const textNodeEntriesInSelection = [];
  while (nextTextNodeEntry != null) {
    textNodeEntriesInSelection.push(nextTextNodeEntry);
    nextTextNodeEntry = textNodeIterator.next().value;
  }

  if (textNodeEntriesInSelection.length === 0) {
    return false;
  }

  return textNodeEntriesInSelection.some(
    ([textNode]) => getCommentThreadsOnTextNode(textNode).size === 0,
  );
}

export function getSmallestCommentThreadAtTextNode(
  editor: Editor,
  textNode: any,
) {
  const commentThreads = getCommentThreadsOnTextNode(textNode);
  const commentThreadsAsArray = [...commentThreads];

  let shortestCommentThreadID = commentThreadsAsArray[0];

  const reverseTextNodeIterator = (slateEditor: Editor, nodePath: Path) =>
    Editor.previous(slateEditor, {
      at: nodePath,
      mode: "lowest",
      match: Text.isText,
    });

  const forwardTextNodeIterator = (slateEditor: Editor, nodePath: Path) =>
    Editor.next(slateEditor, {
      at: nodePath,
      mode: "lowest",
      match: Text.isText,
    });

  if (commentThreads.size > 1) {
    // The map here tracks the lengths of the comment threads.
    // We initialize the lengths with length of current text node
    // since all the comment threads span over the current text node
    // at the least.
    const commentThreadsLengthByID = new Map(
      commentThreadsAsArray.map((id) => [id, textNode.text.length]),
    );

    // traverse in the reverse direction and update the map
    updateCommentThreadLengthMap(
      editor,
      commentThreads,
      reverseTextNodeIterator,
      commentThreadsLengthByID,
    );

    // traverse in the forward direction and update the map
    updateCommentThreadLengthMap(
      editor,
      commentThreads,
      forwardTextNodeIterator,
      commentThreadsLengthByID,
    );

    let minLength = Number.POSITIVE_INFINITY;

    // Find the thread with the shortest length.
    for (const [threadID, length] of commentThreadsLengthByID) {
      if (length < minLength) {
        shortestCommentThreadID = threadID;
        minLength = length;
      }
    }
  }

  return shortestCommentThreadID;
}
