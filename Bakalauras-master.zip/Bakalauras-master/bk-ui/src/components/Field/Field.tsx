import styles from "./field.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

interface FieldProps {
  children: React.ReactNode;
  label?: string;
  formField: string;
  errorMessage?: string;
  className?: string;
  isRow?: boolean;
  noMargin?: boolean;
}

export const Field: React.FC<FieldProps> = ({
  children,
  label,
  formField,
  errorMessage,
  className = "",
  noMargin = false,
  isRow = false,
}) => {
  return (
    <div
      className={`
      ${cx("field")} 
      ${className} 
      ${isRow ? cx("field--is-row") : ""} 
      ${noMargin ? cx("field--no-margin") : ""}`}
    >
      <label className={cx("field__label")} htmlFor={formField}>
        {label}
      </label>
      {children}
      <small className="p-error mt-1">{errorMessage}</small>
    </div>
  );
};
