import { Button } from "primereact/button";

import classNames from "classnames/bind";
import styles from "./grade-view.module.scss";
import { trpc } from "utils/trpc";
import { FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useParams } from "react-router-dom";
import {
  defaultGradeViewValues,
  GradeViewField,
  gradeViewSchema,
} from "./model";
import { BaseInputText } from "components/form-fields/BaseInputText";
import { useEffect, useRef } from "react";
import { UserSessionRole } from "types/enums";
import { Toast } from "primereact/toast";

const cx = classNames.bind(styles);

interface GradeViewProps {
  documentOwnerId?: string;
}

export const GradeView: React.FC<GradeViewProps> = ({ documentOwnerId }) => {
  const { sessionId, documentId } = useParams() as {
    sessionId: string;
    documentId: string;
  };
  const sessionRole = trpc.session.getSessionRole.useQuery({ sessionId });
  const methods = useForm({
    resolver: zodResolver(gradeViewSchema),
    defaultValues: defaultGradeViewValues,
  });

  const {
    handleSubmit,
    getValues,
    setValue,
    formState: { errors },
  } = methods;

  const toastRef = useRef<Toast>();
  const submitGrade = trpc.document.submitGrade.useMutation();
  const sessionDocument = trpc.document.getDocument.useQuery({
    sessionId,
    ownerId: documentOwnerId,
  });

  useEffect(() => {
    setValue(
      "grade",
      sessionDocument.data?.sessionDocuments[0].grade.toString()
    );
    setValue("gradeNote", sessionDocument.data?.sessionDocuments[0].gradeNote);
  }, [sessionDocument.data]);

  const handleSubmitGrade = () => {
    if (!documentOwnerId) {
      return;
    }

    console.log(getValues());

    const { grade, gradeNote } = getValues();
    submitGrade
      .mutateAsync({
        grade: parseInt(grade),
        gradeNote,
        sessionDocumentId: documentId,
      })
      .then(() => {
        sessionDocument.refetch();
        toastRef.current?.show({
          detail: "Grade updated",
          severity: "success",
        });
      });
  };

  if (sessionRole.data === UserSessionRole.MEMBER) {
    return (
      <div className={cx("grade-view")}>
        <h5 className={cx("grade-view__heading")}>
          Grade: {sessionDocument.data?.sessionDocuments[0].grade} / 10
        </h5>
        <p className={cx("grade-view__text")}>
          Note: {sessionDocument.data?.sessionDocuments[0].gradeNote}
        </p>
      </div>
    );
  }
  console.log(sessionDocument.data);
  return (
    <FormProvider {...methods}>
      <form
        onSubmit={handleSubmit(handleSubmitGrade)}
        className={cx("grade-view")}
      >
        <Toast ref={toastRef} />
        <BaseInputText
          formField={GradeViewField.GRADE}
          type="number"
          label="Grade (1-10)"
          errorMessage={errors.grade?.message}
        />
        <BaseInputText
          formField={GradeViewField.GRADE_NOTE}
          label="Feedback"
          errorMessage={errors.gradeNote?.message}
          textarea
        />
        <Button type="submit" className="w-full">
          {sessionDocument.data?.sessionDocuments[0].grade
            ? "Update review"
            : "Submit review"}
        </Button>
      </form>
    </FormProvider>
  );
};
