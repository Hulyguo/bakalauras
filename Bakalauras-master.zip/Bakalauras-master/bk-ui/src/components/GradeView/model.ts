import { string, z } from "zod";

export const GradeViewField = {
  GRADE: "grade",
  GRADE_NOTE: "gradeNote",
} as const;

export const gradeViewSchema = z.object({
  [GradeViewField.GRADE]: string(),
  [GradeViewField.GRADE_NOTE]: string().trim(),
});

export const defaultGradeViewValues = {
  [GradeViewField.GRADE]: "",
  [GradeViewField.GRADE_NOTE]: "",
};
