import { TabView, TabPanel } from "primereact/tabview";
import { MessageView } from "components/MessageView/MessageView";
import { GradeView } from "components/GradeView/GradeView";

import classNames from "classnames/bind";
import styles from "./header.module.scss";
import { SessionSettings } from "components/SessionLobby/SessionSettings/SessionSettings";
import { trpc } from "utils/trpc";
import { useParams } from "react-router-dom";
import { SessionStatus } from "types/enums";

const cx = classNames.bind(styles);

interface HeaderProps {
  contentRender: React.ReactNode;
  activeHeaderIndex: number;
  isTeacher: boolean;
  documentOwnerId?: string;
  messages?: any;
  setActiveHeaderIndex: (index: number) => void;
}

export const Header: React.FC<HeaderProps> = ({
  contentRender,
  documentOwnerId,
  messages,
  isTeacher,
  activeHeaderIndex,
  setActiveHeaderIndex,
}) => {
  const { sessionId } = useParams() as { sessionId: string };
  const session = trpc.session.getSession.useQuery({ sessionId });

  return (
    <div className={cx("header")}>
      <div className="card">
        <TabView
          className={cx("header__tab")}
          activeIndex={activeHeaderIndex}
          key={activeHeaderIndex}
          onTabChange={(e) => {
            setActiveHeaderIndex(e.index);
          }}
        >
          <TabPanel header="Text Editor" leftIcon="pi pi-calendar mr-2">
            {contentRender}
          </TabPanel>
          <TabPanel
            className={cx("header__messages", {
              "header__messages--active": messages?.length > 0,
            })}
            header={`Messages ${messages?.length > 0 ? "(new: " + messages?.length + ")" : ""}`}
            leftIcon="pi pi-envelope mr-2"
          >
            <MessageView documentOwnerId={documentOwnerId} />
          </TabPanel>
          {session.data?.sessionStatus === SessionStatus.Finalized && (
            <TabPanel header="Grading">
              <GradeView documentOwnerId={documentOwnerId} />
            </TabPanel>
          )}
          <TabPanel header="Session Settings" leftIcon="pi pi-cog mr-2">
            <SessionSettings isTeacher={isTeacher} />
          </TabPanel>
        </TabView>
      </div>
    </div>
  );
};
