import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "primereact/button";
import { FormProvider, useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { trpc } from "utils/trpc";
import { BaseInputText } from "components/form-fields/BaseInputText";
import {
  defaultInitializeSessionFormValues,
  InitializeSessionFormField,
  initializeSessionFormSchema,
} from "./model";

export const InitializeSessionForm: React.FC = () => {
  const methods = useForm({
    resolver: zodResolver(initializeSessionFormSchema),
    defaultValues: defaultInitializeSessionFormValues,
  });

  const {
    handleSubmit,
    getValues,
    formState: { errors },
  } = methods;

  const initializeSession = trpc.session.initializeSession.useMutation();
  const navigate = useNavigate();

  const handleInitializeSession = () => {
    const { sessionName } = getValues();

    initializeSession.mutate(
      { sessionName },
      {
        onSuccess: ({ sessionId }) => {
          navigate(`/dashboard/session-lobby/${sessionId}`);
        },
      }
    );
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(handleInitializeSession)} className="m-auto">
        <BaseInputText
          label="Session name"
          formField={InitializeSessionFormField.SESSION_NAME}
          errorMessage={errors.sessionName?.message}
        />
        <Button label="Initialize session" className="w-full" />
      </form>
    </FormProvider>
  );
};
