import { z } from "zod";
import { ZodValidationUtils } from "utils/zodValidationUtils";

export const InitializeSessionFormField = {
  SESSION_NAME: "sessionName",
} as const;

export const initializeSessionFormSchema = z.object({
  [InitializeSessionFormField.SESSION_NAME]: ZodValidationUtils.trimmedString,
});

export const defaultInitializeSessionFormValues = {
  [InitializeSessionFormField.SESSION_NAME]: "",
};
