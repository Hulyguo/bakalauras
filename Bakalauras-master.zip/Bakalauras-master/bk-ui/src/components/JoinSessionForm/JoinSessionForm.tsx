import { FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import classNames from "classnames";
import { Field } from "components/Field/Field";
import {
  defaultJoinSessionFormValues,
  JoinSessionFormField,
  joinSessionFormSchema,
} from "./model";
import { Toast } from "primereact/toast";

import bind from "classnames/bind";
import styles from "./join-session-form.module.scss";
import { trpc } from "utils/trpc";
import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { BaseInputText } from "components/form-fields/BaseInputText";

const cx = bind.bind(styles);

export const JoinSessionForm: React.FC = () => {
  const navigate = useNavigate();
  const toast = useRef<Toast | null>(null);
  const joinSession = trpc.session.joinSession.useMutation();

  const methods = useForm({
    resolver: zodResolver(joinSessionFormSchema),
    defaultValues: defaultJoinSessionFormValues,
  });

  const {
    getValues,
    handleSubmit,
    formState: { errors },
    setError,
  } = methods;

  const submitForm = () => {
    const { sessionId } = getValues();

    joinSession.mutate(
      { sessionId },
      {
        onSuccess: (sessionUser) => {
          navigate(`/dashboard/session-lobby/${sessionUser.sessionId}`);
        },
        onError: () => {
          setError("sessionId", {
            message: "Session with this Id does not exist",
            type: "value",
          });
        },
      }
    );
  };

  return (
    <>
      <Toast ref={toast} />
      <FormProvider {...methods}>
        <form
          className={cx("join-session-form")}
          onSubmit={handleSubmit(submitForm)}
        >
          <BaseInputText
            label="Session Id"
            formField={JoinSessionFormField.SESSION_ID}
            errorMessage={errors.sessionId?.message}
            iconNode={<i className="pi pi-lock" />}
          />
          {/* <Field
          label="Session ID"
          formField={JoinSessionFormField.SESSION_ID}
          errors={errors.sessionId?.message}
        >
          <span className="p-input-icon-left">
            <i className="pi pi-lock" />
            <InputText
              id={JoinSessionFormField.SESSION_ID}
              {...register(JoinSessionFormField.SESSION_ID)}
              className={`w-full ${classNames({ "p-invalid": errors.sessionId?.message })}`}
              placeholder="Session ID"
            />
          </span>
        </Field> */}
          <Button
            loading={joinSession.isLoading}
            label="Join session"
            className="w-full"
          />
        </form>
      </FormProvider>
    </>
  );
};
