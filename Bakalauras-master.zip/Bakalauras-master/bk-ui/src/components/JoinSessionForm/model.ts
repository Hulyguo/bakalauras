import { z } from "zod";

export const joinSessionFormSchema = z.object({
  sessionId: z.string().min(1, { message: "Enter a session ID" }),
});

export enum JoinSessionFormField {
  SESSION_ID = "sessionId",
}

export const defaultJoinSessionFormValues = {
  sessionId: "",
};
