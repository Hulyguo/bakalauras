import { Outlet } from "react-router-dom";

import styles from "./landing.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

export const Landing: React.FC = () => {
  return (
    <div className={cx("landing")}>
      <Outlet />
    </div>
  );
};
