import { FormProvider, useForm } from "react-hook-form";
import { BaseInputText } from "components/form-fields/BaseInputText";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  defaultLoginFormValues,
  LoginFormField,
  loginFormSchema,
} from "./model";
import { Button } from "primereact/button";
import { NavLink, useNavigate } from "react-router-dom";
import { Divider } from "primereact/divider";
import { trpc } from "utils/trpc";
import { useCookies } from "react-cookie";
import { useQueryClient } from "@tanstack/react-query";
import { AUTHENTICATION_COOKIE } from "utils/constants";
import { useEffect, useRef } from "react";

import styles from "./login.module.scss";
import classNames from "classnames/bind";
import { Toast } from "primereact/toast";

const cx = classNames.bind(styles);

export const Login: React.FC = () => {
  const toastRef = useRef<Toast>();
  const navigate = useNavigate();
  const [cookies, setCookie] = useCookies();
  const queryClient = useQueryClient();
  const methods = useForm({
    resolver: zodResolver(loginFormSchema),
    defaultValues: defaultLoginFormValues,
  });

  const {
    handleSubmit,
    formState: { errors },
  } = methods;

  const login = trpc.authentication.login.useMutation();

  const submitForm = () => {
    const { username, password } = methods.getValues();
    login.mutate(
      { password, username },
      {
        onSuccess: ({ csrfToken }) => {
          queryClient.clear();
          setCookie(AUTHENTICATION_COOKIE, csrfToken, { path: "/" });
        },
        onError: () => {
          toastRef.current?.show({
            summary: "Invalid credentials",
            severity: "error",
          });
        },
      },
    );
  };

  useEffect(() => {
    if (!cookies[AUTHENTICATION_COOKIE]) {
      return;
    }

    navigate("/dashboard");
  }, [cookies[AUTHENTICATION_COOKIE]]);

  return (
    <FormProvider {...methods}>
      <Toast ref={toastRef} />
      <form onSubmit={handleSubmit(submitForm)}>
        <BaseInputText
          label={"Username"}
          formField={LoginFormField.USERNAME}
          errorMessage={errors.username?.message}
        />
        <BaseInputText
          type="password"
          label={"Password"}
          formField={LoginFormField.PASSWORD}
          errorMessage={errors.password?.message}
        />
        <Button label="Login" className="w-full" />
      </form>
      <Divider />
      <div className={cx("login__register")}>
        <span className={cx("login__register-text")}>
          Don't have an account?
        </span>
        <NavLink to={"/register"}>Register</NavLink>
      </div>
    </FormProvider>
  );
};
