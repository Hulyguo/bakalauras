import { string, z } from "zod";

export const loginFormSchema = z.object({
  username: string({ invalid_type_error: "Enter a username" })
    .min(1, { message: "Enter a username" })
    .trim(),
  password: string({ invalid_type_error: "Enter a password" })
    .min(1, { message: "Enter a password" })
    .trim(),
});

export enum LoginFormField {
  USERNAME = "username",
  PASSWORD = "password",
}

export const defaultLoginFormValues = {
  username: "",
  password: "",
};
