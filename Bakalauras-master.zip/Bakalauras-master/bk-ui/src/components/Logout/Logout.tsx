import { useEffect } from "react";
import { useCookies } from "react-cookie";
import { useNavigate } from "react-router-dom";
import { AUTHENTICATION_COOKIE } from "utils/constants";

export const Logout: React.FC = () => {
  const [, , removeCookie] = useCookies();
  const navigate = useNavigate();

  useEffect(() => {
    removeCookie(AUTHENTICATION_COOKIE);
    navigate("/login");
  }, []);

  return <div></div>;
};
