import styles from "./message.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

interface MessageProps {
  message: string;
  sent: string;
  isSender: boolean;
}

export const Message: React.FC<MessageProps> = ({
  message,
  sent,
  isSender,
}) => {
  const messageClasses = cx("message__content", {
    "message--received": !isSender,
    "message--sent": isSender,
  });

  const messageTextClasses = cx("message__text", {
    "message__text--received": !isSender,
    "message__text--sent": isSender,
  });

  return (
    <div className={cx("message")}>
      <div className={messageClasses}>
        <div className={messageTextClasses}>
          <span>{message}</span>
        </div>
        <span className={cx("message__timestamp")}>{sent}</span>
      </div>
    </div>
  );
};
