import styles from "./message-view.module.scss";
import classNames from "classnames/bind";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { Message } from "./Message/Message";
import { trpc } from "utils/trpc";
import { useState, useRef } from "react";
import { useParams } from "react-router-dom";
import { Toast } from "primereact/toast";
import { format } from "date-fns";

const cx = classNames.bind(styles);

interface MessageViewProps {
  documentOwnerId?: string;
}

export const MessageView: React.FC<MessageViewProps> = ({
  documentOwnerId,
}) => {
  const bottomRef = useRef<HTMLDivElement>();
  const { sessionId } = useParams() as {
    sessionId: string;
  };
  const [messageValue, setMessageValue] = useState("");
  const toastRef = useRef<Toast | null>(null);

  const getMessages = trpc.message.getMessages.useQuery(
    { sessionId },
    {
      refetchOnWindowFocus: false,
      onSettled: () => {
        bottomRef.current?.scrollIntoView();
      },
    }
  );

  const sessionMembersWithMesages =
    trpc.session.getSessionMembersWithMessages.useQuery(
      { sessionId },
      {
        refetchOnWindowFocus: false,
      }
    );

  const session = trpc.session.getSession.useQuery({ sessionId });

  const sendMessage = trpc.message.sendMessage.useMutation();
  trpc.message.onMessageSent.useSubscription(
    { sessionId },
    {
      onData: () => {
        getMessages.refetch();
        sessionMembersWithMesages.refetch();
      },
    }
  );

  const handleMessageSend = () => {
    const recipientId = documentOwnerId ?? undefined;
    sendMessage.mutate(
      { message: messageValue, recipientId, sessionId },
      {
        onSuccess: () => {
          setMessageValue("");
          getMessages.refetch();
        },
      }
    );
  };

  console.log(getMessages.data);

  return (
    <div className={cx("message-view")}>
      <Toast ref={toastRef} />
      <div className={cx("message-view__content")}>
        {getMessages.data?.map((message) => (
          <Message
            key={message.id}
            isSender={message.isSender}
            message={message.message}
            sent={format(new Date(message.sent), "eee MM/dd H:mm")}
          />
        ))}
        <div ref={bottomRef}></div>
      </div>
      {session.data?.sessionStatus !== "Finalized" && (
        <div className={cx("message-view__actions")}>
          <InputText
            placeholder="Your message"
            value={messageValue}
            onChange={(e) => setMessageValue(e.target.value)}
            className={cx("message-view__input")}
          />
          <Button
            onClick={handleMessageSend}
            label="Send message"
            iconPos="right"
            icon="pi pi-send"
          />
        </div>
      )}
    </div>
  );
};
