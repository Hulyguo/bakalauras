import React from "react";
import { Password } from "primereact/password";
import { Divider } from "primereact/divider";

import styles from "./password-field.module.scss";
import classNames from "classnames/bind";

export const cx = classNames.bind(styles);
import {
  hasAlpha,
  hasAtLeastCharacters,
  hasNumber,
  hasSpecialSymbol,
} from "./utils";
import { Controller, useFormContext } from "react-hook-form";
import { Field } from "components/Field/Field";

interface PasswordFieldProps {
  formField: string;
  label: string;
  className?: string;
  placeholder?: string;
  errorMessage?: string;
}

export const PasswordField: React.FC<PasswordFieldProps> = ({
  label,
  errorMessage,
  formField,
  className,
  placeholder,
}) => {
  const formContext = useFormContext();
  const header = <h4 className="mb-2">Choose a password</h4>;

  const renderFooter = (value: string) => (
    <div className="flex flex-column">
      <Divider />
      <p className="mt-2 mr-auto mb-3">Requirements:</p>
      <ul className="pl-2 ml-2 mt-0" style={{ lineHeight: "1.5" }}>
        <li
          className={`${cx("password-field")} ${hasAtLeastCharacters(value, 8) ? cx("password-field--valid") : cx("password-field--invalid")}`}
        >
          At least 8 symbols
        </li>
        <li
          className={`${cx("password-field")} ${hasSpecialSymbol(value) ? cx("password-field--valid") : cx("password-field--invalid")}`}
        >
          At least 1 special symbol (! @ $ ...)
        </li>
        <li
          className={`${cx("password-field")} ${hasAlpha(value) ? cx("password-field--valid") : cx("password-field--invalid")}`}
        >
          Has letters
        </li>
        <li
          className={`${cx("password-field")} ${hasNumber(value) ? cx("password-field--valid") : cx("password-field--invalid")}`}
        >
          Has numbers
        </li>
      </ul>
    </div>
  );

  return (
    <Field label={label} formField={formField} errorMessage={errorMessage}>
      <Controller
        name={formField}
        control={formContext.control}
        render={({ field }) => (
          <Password
            {...field}
            icon={<i className="pi pi-lock" />}
            inputClassName="w-full"
            inputRef={field.ref}
            header={header}
            footer={renderFooter(field.value)}
            toggleMask
            placeholder={placeholder}
            weakLabel="Weak"
            mediumLabel="Average"
            mediumRegex="^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$"
            strongLabel="Strong"
            strongRegex="^(?=.*[a-z])(?=.*\d)(?=.*[{}#@~$!(),.<>\+\_\-\=%*\[\]^?&])[A-Za-z\d@()$#~{} \[\]\+\_\-\=,.<>^!%*?&]{8,}$"
            className={className}
          />
        )}
      />
    </Field>
  );
};
