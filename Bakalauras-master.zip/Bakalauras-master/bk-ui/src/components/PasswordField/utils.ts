export const hasAtLeastCharacters = (value: string, count: number) => {
  return value.length >= count;
};

export const hasSpecialSymbol = (value: string) => {
  return new RegExp(`[$&+,:;=?@#|'<>.^*()%!-]`).test(value);
};

export const hasAlpha = (value: string) => {
  return new RegExp(`[a-zA-Z]`).test(value);
};

export const hasNumber = (value: string) => {
  return new RegExp(`[/d]`).test(value);
};
