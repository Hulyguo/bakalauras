import { zodResolver } from "@hookform/resolvers/zod";
import { FormProvider, useForm } from "react-hook-form";
import { Button } from "primereact/button";
import { Divider } from "primereact/divider";
import { NavLink, useNavigate } from "react-router-dom";
import {
  defaultRegisterFormValues,
  RegisterFormField,
  registerFormSchema,
} from "./model";
import { BaseInputText } from "components/form-fields/BaseInputText";
import { trpc } from "utils/trpc";
import { PasswordField } from "components/PasswordField/PasswordField";

import styles from "./register.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

export const Register: React.FC = () => {
  const navigate = useNavigate();
  const methods = useForm({
    resolver: zodResolver(registerFormSchema),
    defaultValues: defaultRegisterFormValues,
  });

  const {
    handleSubmit,
    getValues,
    formState: { errors },
  } = methods;

  const registerUser = trpc.authentication.register.useMutation();

  const submitForm = async () => {
    const form = getValues();
    const { repeatPassword, ...rest } = form;
    registerUser.mutate(rest, {
      onSuccess: (res) => {
        const { isEmailUnique, isUsernameUnique } = res;
        if (!isEmailUnique) {
          methods.setError("email", { message: "Email is already taken" });
        }

        if (!isUsernameUnique) {
          methods.setError("username", {
            message: "Username is already taken",
          });
        }

        if (isEmailUnique && isUsernameUnique) {
          navigate("/login");
        }
      },
    });
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(submitForm)}>
        <BaseInputText
          label="Username"
          iconNode={<i className="pi pi-user" />}
          formField={RegisterFormField.USERNAME}
          errorMessage={errors.username?.message}
        />
        <BaseInputText
          label="Name"
          iconNode={<i className="pi pi-user" />}
          formField={RegisterFormField.NAME}
          errorMessage={errors.firstName?.message}
        />
        <BaseInputText
          label="Surname"
          iconNode={<i className="pi pi-user" />}
          formField={RegisterFormField.SURNAME}
          errorMessage={errors.lastName?.message}
        />
        <PasswordField
          label="Password"
          placeholder="Password"
          formField={RegisterFormField.PASSWORD}
          errorMessage={errors.password?.message}
        />
        <PasswordField
          label="Repeat password"
          placeholder="Repeat password"
          formField={RegisterFormField.REPEAT_PASSWORD}
          errorMessage={errors.repeatPassword?.message}
        />
        <BaseInputText
          label="Email"
          iconNode={<i className="pi pi-envelope" />}
          formField={RegisterFormField.EMAIL}
          errorMessage={errors.email?.message}
        />
        <Button label="Sign up" className="w-full" />
      </form>
      <Divider />
      <div className={cx("register__login")}>
        <span className={cx("register__login-text")}>
          Already have an account?
        </span>
        <NavLink to={"/login"}>Log in</NavLink>
      </div>
    </FormProvider>
  );
};
