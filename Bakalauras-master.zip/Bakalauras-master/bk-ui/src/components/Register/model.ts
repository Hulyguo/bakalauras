import { string, z } from "zod";
import { ZodValidationUtils } from "utils/zodValidationUtils";

export const RegisterFormField = {
  USERNAME: "username",
  PASSWORD: "password",
  REPEAT_PASSWORD: "repeatPassword",
  EMAIL: "email",
  NAME: "firstName",
  SURNAME: "lastName",
} as const;

export const registerFormSchema = z
  .object({
    [RegisterFormField.USERNAME]: string({
      invalid_type_error: "Enter a username",
    })
      .min(1, { message: "Enter a username" })
      .trim(),
    [RegisterFormField.PASSWORD]: ZodValidationUtils.password,
    [RegisterFormField.REPEAT_PASSWORD]: string({
      invalid_type_error: "Repeat your password",
    })
      .min(1, { message: "Repeat your password" })
      .trim(),
    [RegisterFormField.EMAIL]: ZodValidationUtils.trimmedString
      .email({ message: "Invalid email" })
      .min(1, { message: "Enter an email" }),
    [RegisterFormField.NAME]: string({ invalid_type_error: "Enter a name" })
      .min(1, { message: "Enter a name" })
      .trim(),
    [RegisterFormField.SURNAME]: string({
      invalid_type_error: "Enter a surname",
    })
      .min(1, { message: "Enter a surname" })
      .trim(),
  })
  .refine((data) => data.password === data.repeatPassword, {
    path: [RegisterFormField.PASSWORD],
    message: "Passwords do not match",
  });

export const defaultRegisterFormValues = {
  [RegisterFormField.USERNAME]: "",
  [RegisterFormField.PASSWORD]: "",
  [RegisterFormField.REPEAT_PASSWORD]: "",
  [RegisterFormField.EMAIL]: "",
  [RegisterFormField.NAME]: "",
  [RegisterFormField.SURNAME]: "",
};
