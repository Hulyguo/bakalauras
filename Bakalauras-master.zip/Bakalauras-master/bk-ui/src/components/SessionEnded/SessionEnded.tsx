import { Button } from "components/Editor/components";

export const SessionEnded: React.FC = () => {
  return (
    <div>
      <h1>The session has ended!</h1>
      <Button>Return to dashboard.</Button>
    </div>
  );
};
