import { Button } from "primereact/button";
import { useNavigate, useParams } from "react-router-dom";
import { trpc } from "utils/trpc";

import styles from "./session-lobby.module.scss";
import classNames from "classnames/bind";
import { Toast } from "primereact/toast";
import { useRef } from "react";
import { ProgressSpinner } from "primereact/progressspinner";
import { SessionStatus, UserSessionRole } from "types/enums";

const cx = classNames.bind(styles);

export const SessionLobby: React.FC = () => {
  const navigate = useNavigate();
  const toastRef = useRef<Toast | null>(null);
  const context = trpc.useContext();
  const { sessionId } = useParams() as {
    sessionId: string;
    userId: string;
  };

  const sessionMembers = trpc.session.getSessionMembers.useQuery({ sessionId });
  const updateSessionStatus = trpc.session.updateSessionStatus.useMutation();
  const sessionRole = trpc.session.getSessionRole.useQuery({ sessionId });

  const getSession = trpc.session.getSession.useQuery({ sessionId });
  const fetchMyDocuments = trpc.document.fetchMySessionDocuments.useMutation();

  trpc.session.onJoinSession.useSubscription(
    { sessionId },
    {
      onStarted: () => {},
      onData: (data) => {
        context.session.getSessionMembers.setData({ sessionId }, (old) => {
          const addedUser = {
            id: data.user.id,
            firstName: data.user.firstName,
            lastName: data.user.lastName,
          };
          if (!old) return [];
          return [...(old ?? []), addedUser];
        });
      },
    }
  );

  const isOwner = () => {
    if (!sessionRole.data) {
      return null;
    }

    return sessionRole.data === UserSessionRole.ADMIN;
  };

  trpc.session.onSessionStatusChange.useSubscription(
    { sessionId },
    {
      onData: () => {
        if (sessionRole.data === UserSessionRole.MEMBER) {
          fetchMyDocuments.mutate(
            { sessionId },
            {
              onSuccess: (res) => {
                if (!res) return;
                navigate(
                  `/dashboard/session-user/${sessionId}/${res.sessionDocuments[0].id}`
                );
              },
            }
          );
        }
      },
      enabled: sessionRole.data != undefined,
    }
  );

  const startSession = () => {
    if (!sessionMembers.data) return;
    if (sessionMembers.data?.length === 0) {
      return toastRef.current?.show({
        summary: "Cannot start session without students",
        severity: "info",
      });
    }

    updateSessionStatus.mutate(
      { sessionId, sessionStatus: SessionStatus.InProgress },
      {
        onSuccess: () => {
          navigate(`/dashboard/session-admin/${sessionId}`);
        },
      }
    );
  };

  if (!sessionMembers.data) return <ProgressSpinner className="m-auto" />;

  return (
    <div className={cx("session-lobby")}>
      <Toast ref={toastRef} />
      {isOwner() ? (
        <h1 className={cx("session-lobby__title")}>Admin</h1>
      ) : (
        <h1 className={cx("session-lobby__title")}></h1>
      )}
      <h3 className="mb-4">Session name: {getSession.data?.sessionName}</h3>
      <p className={cx("session-lobby__id")}>
        Session Id: <strong>{sessionId}</strong>
      </p>
      <p className={cx("session-lobby__count")}>
        Student count: {sessionMembers.data.length}
      </p>
      <div className={cx("session-lobby__students")}>
        {sessionMembers.data.map(({ firstName, lastName, id }) => (
          <p key={id}>{`${firstName} ${lastName}`}</p>
        ))}
      </div>
      {isOwner() && (
        <Button
          className="w-full"
          label="Begin session"
          onClick={startSession}
        />
      )}
    </div>
  );
};
