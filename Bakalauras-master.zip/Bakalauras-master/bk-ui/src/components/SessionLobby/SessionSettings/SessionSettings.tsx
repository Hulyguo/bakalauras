import styles from "./session-settings.module.scss";
import classNames from "classnames/bind";
import { trpc } from "utils/trpc";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "primereact/button";

const cx = classNames.bind(styles);

interface SessionSettingsProps {
  isTeacher: boolean;
}

export const SessionSettings: React.FC<SessionSettingsProps> = ({
  isTeacher,
}) => {
  const { documentId, sessionId } = useParams() as {
    sessionId: string;
    documentId: string;
  };
  const navigate = useNavigate();
  const submitDocument = trpc.document.changeState.useMutation();
  const session = trpc.session.getSession.useQuery({ sessionId });

  const handleSubmit = () => {
    submitDocument.mutate(
      {
        sessionDocumentId: documentId,
        status: "SUBMITTED",
      },
      {
        onSuccess: () => {
          navigate("/dashboard");
        },
      }
    );
  };

  return (
    <div className={cx("session-settings")}>
      {session.data?.sessionStatus === "Finalized" && (
        <h3>Document is submitted</h3>
      )}
      <Button
        icon="pi pi-sign-out"
        iconPos="right"
        severity="secondary"
        className="mb-4"
        onClick={() => navigate("/dashboard/user-sessions")}
      >
        <span className="ml-1">Leave session</span>
      </Button>
      {session.data?.sessionStatus !== "Finalized" && !isTeacher && (
        <Button onClick={handleSubmit}>Submit work</Button>
      )}
    </div>
  );
};
