import { debounce } from "lodash";
import { useParams } from "react-router-dom";
import { BaseOperation, Descendant } from "slate";
import { trpc } from "utils/trpc";
import { SlateEditor } from "components/Editor/Editor";
import { useEditorCommentContext } from "components/Editor/providers/EditorCommentsProvider";

export const StudentContentRender: React.FC = () => {
  const { data } = trpc.authentication.myUser.useQuery();

  const context = trpc.useContext();
  const { sessionId, documentId } = useParams() as {
    sessionId: string;
    documentId: string;
    userId: string;
  };
  const { refetchCommentThreads } = useEditorCommentContext();

  const document = trpc.document.getDocument.useQuery(
    { sessionId },
    {
      refetchOnWindowFocus: false,
    },
  );
  const session = trpc.session.getSession.useQuery({ sessionId });

  const updateDocument = trpc.document.updateDocument.useMutation();

  const updateDocumentDebounced = debounce(
    (value: Descendant[], operations: BaseOperation[]) => {
      updateDocument.mutate({
        document: JSON.stringify(value),
        operations,
        sessionId,
        documentId,
      });
    },
    500,
  );

  trpc.comment.onAddCommentThread.useSubscription(
    { documentId },
    {
      onData: () => {
        refetchCommentThreads();
      },
    },
  );

  trpc.comment.onAddCommentToThread.useSubscription(
    { documentOwnerId: undefined },
    {
      onData: () => {
        refetchCommentThreads();
      },
    },
  );

  trpc.document.onDocumentUpdate.useSubscription(
    { documentId, userId: data?.user.id },
    {
      onData: (onDocumentUpdateData) => {
        context.document.getDocument.setData({ sessionId }, () => {
          return { sessionDocuments: [onDocumentUpdateData] };
        });
      },
      enabled: document.data != undefined,
    },
  );

  if (!document.data) return <p>"Document not found"</p>;

  return (
    <div>
      <SlateEditor
        key={document.data.sessionDocuments[0].document as string}
        onChange={updateDocumentDebounced}
        document={
          JSON.parse(
            document.data.sessionDocuments[0].document as string,
          ) as Descendant[]
        }
        sessionStatus={session.data?.sessionStatus}
      />
    </div>
  );
};
