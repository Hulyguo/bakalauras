export const StudentHome: React.FC = () => {
  return (
    <div>
      <h1>My sessions</h1>
      <div></div>
    </div>
  );
};
