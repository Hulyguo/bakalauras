import styles from "./student-card.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

interface StudentCardProps {
  username: string;
  onClick: () => void;
  unreadCount: number;
  isActive: boolean;
  text?: string;
  timestamp?: Date;
}

export const StudentCard: React.FC<StudentCardProps> = ({
  username,
  onClick,
  unreadCount,
  text,
  timestamp,
  isActive,
}) => {
  const studentCardClasses = cx("student-card", {
    "student-card--active": isActive,
  });

  return (
    <div className={studentCardClasses} onClick={onClick} onKeyDown={onClick}>
      <div className={cx("student-card__avatar")}>
        <i className="pi pi-user" style={{ fontSize: "1.25rem" }} />
      </div>
      <div className={cx("student-card__details")}>
        <span className={cx("student-card__username")}>{username}</span>
        <div className={cx("student-card__info")}>
          <div className={cx("student-card__message")}>{text}</div>
          {timestamp && (
            <span className={cx("student-card__timestamp")}>
              {new Date(timestamp).toLocaleString()}
            </span>
          )}
        </div>
      </div>
      {unreadCount > 0 && (
        <span className={cx("student-card__unread")}>{unreadCount}</span>
      )}
    </div>
  );
};
