import { StudentCard } from "./StudentCard/StudentCard";
import { InputText } from "primereact/inputtext";
import { trpc } from "utils/trpc";
import { useNavigate, useParams } from "react-router-dom";
import { useState } from "react";
import { Button } from "@mui/material";

interface StudentListProps {
  onChange: (ownerId: string) => void;
  newMessages: any[];
  documentOwnerId?: string;
}

export const StudentList: React.FC<StudentListProps> = ({
  newMessages,
  onChange,
}) => {
  const navigate = useNavigate();
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(
    null
  );
  const { sessionId } = useParams() as { sessionId: string; userId: string };
  const [, setStudentFilter] = useState("");
  const updateSessionStatus = trpc.session.updateSessionStatus.useMutation();
  const sessionMembersWithMesages =
    trpc.session.getSessionMembersWithMessages.useQuery(
      { sessionId },
      {
        refetchOnWindowFocus: false,
      }
    );
  const session = trpc.session.getSession.useQuery({ sessionId });

  const renderStudentCard = (
    studentId: string,
    username: string,
    lastMessage: any,
    documentId?: string
  ) => {
    const unreadCount = (newMessages[studentId] ?? []).length;

    return (
      <StudentCard
        text={lastMessage?.message.message}
        timestamp={lastMessage?.message.sent}
        isActive={selectedStudentId === studentId}
        unreadCount={unreadCount}
        key={studentId}
        onClick={() => {
          setSelectedStudentId(studentId);
          onChange(studentId);
          navigate(`/dashboard/session-admin/${sessionId}/${documentId}`);
        }}
        username={username}
      />
    );
  };

  const endSession = () => {
    if (session.data?.sessionStatus === "Finalized") {
      navigate("/dashboard");
      return;
    }
    updateSessionStatus.mutate({ sessionId, sessionStatus: "Finalized" });
  };

  return (
    <div className="flex-column flex flex-1">
      <span className="p-input-icon-left mb-3 w-full">
        <i className="pi pi-search" />
        <InputText
          className="w-full"
          onChange={(e) => setStudentFilter(e.target.value)}
          placeholder="Search"
        />
      </span>
      <div>
        {sessionMembersWithMesages.data
          ?.filter((sessionMember) => sessionMember.role !== "ADMIN")
          .map((sessionMember) => {
            return renderStudentCard(
              sessionMember.user.id,
              `${sessionMember.user.firstName} ${sessionMember.user.lastName}`,
              sessionMember.session.sessionMessages[
                sessionMember.session.sessionMessages.length - 1
              ],
              sessionMember.sessionDocuments[0].id
            );
          })}
      </div>
      <Button
        onClick={endSession}
        className="mt-auto"
        variant="contained"
        style={{ textTransform: "unset" }}
      >
        {session.data?.sessionStatus === "Finalized" ? "Return" : "End session"}
      </Button>
    </div>
  );
};
