import { useRef, useState } from "react";
import { Header } from "components/Header/Header";

import styles from "./student-view.module.scss";
import classNames from "classnames/bind";
import { StudentContentRender } from "components/StudentContentRender/StudentContentRender";
import { EditorCommentsProvider } from "components/Editor/providers/EditorCommentsProvider";
import { useNavigate, useParams } from "react-router-dom";
import { trpc } from "utils/trpc";
import { Toast } from "primereact/toast";

const cx = classNames.bind(styles);

export const StudentView: React.FC = () => {
  const toastRef = useRef<Toast | null>(null);
  const { sessionId } = useParams() as { sessionId: string };
  const navigate = useNavigate();
  const { userId } = useParams() as { userId: string };
  const [activeHeaderIndex, setActiveHeaderIndex] = useState(0);

  trpc.session.onSessionStatusChange.useSubscription(
    { sessionId },
    {
      onData: () => {
        navigate(`/dashboard/session-ended/${sessionId}`);
      },
    }
  );

  const getMessages = trpc.message.getMessages.useQuery(
    { sessionId },
    {
      refetchOnWindowFocus: false,
    }
  );

  const sessionMembersWithMesages =
    trpc.session.getSessionMembersWithMessages.useQuery(
      { sessionId },
      {
        refetchOnWindowFocus: false,
      }
    );

  trpc.message.onMessageSent.useSubscription(
    { sessionId },
    {
      onData: (data: any) => {
        if (userId !== data.senderId) {
          toastRef.current?.show({
            detail: data.message,
            summary: data.senderId,
            severity: "info",
          });
        }
        getMessages.refetch();
        sessionMembersWithMesages.refetch();
      },
    }
  );

  return (
    <EditorCommentsProvider documentOwnerId={userId}>
      <Toast ref={toastRef} />
      <div className="mb-auto w-full h-full">
        <div className={cx("student-view__content")}>
          <div id="comment-sidebar" className={cx("student-view__sidebar")} />
          <Header
            isTeacher={false}
            activeHeaderIndex={activeHeaderIndex}
            setActiveHeaderIndex={setActiveHeaderIndex}
            contentRender={<StudentContentRender />}
          />
        </div>
      </div>
    </EditorCommentsProvider>
  );
};
