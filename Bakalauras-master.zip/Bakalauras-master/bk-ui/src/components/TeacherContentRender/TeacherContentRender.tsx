import { BaseOperation, Descendant } from "slate";

import { SlateEditor } from "components/Editor/Editor";
import { trpc } from "utils/trpc";
import { ProgressSpinner } from "primereact/progressspinner";
import { useEditorCommentContext } from "components/Editor/providers/EditorCommentsProvider";

import styles from "./teacher-content-render.module.scss";
import classNames from "classnames/bind";
import { SidebarView } from "components/TeacherView/TeacherView";
import { useParams } from "react-router-dom";
import { debounce } from "lodash";

const cx = classNames.bind(styles);

interface TeacherContentRenderProps {
  selectedView: SidebarView;
  activeHeaderIndex: number;
  documentOwnerId?: string;
}

export const TeacherContentRender: React.FC<TeacherContentRenderProps> = ({
  documentOwnerId,
  selectedView,
  activeHeaderIndex,
}) => {
  const { sessionId, documentId } = useParams() as {
    sessionId: string;
    documentId: string;
  };
  const { data: myUserData } = trpc.authentication.myUser.useQuery();
  const context = trpc.useContext();
  const { addCommentToThread, refetchCommentThreads } =
    useEditorCommentContext();

  const documents = trpc.document.getDocument.useQuery(
    { ownerId: documentOwnerId!, sessionId },
    {
      refetchOnWindowFocus: false,
      enabled: documentOwnerId != undefined,
    }
  );

  const session = trpc.session.getSession.useQuery({ sessionId });

  const documentOperations = trpc.document.getDocumentOperations.useQuery(
    { sessionDocumentId: documents?.data?.sessionDocuments[0].id },
    { enabled: !!documents?.data?.sessionDocuments[0] }
  );

  trpc.document.onDocumentUpdate.useSubscription(
    { documentId, userId: myUserData?.user.id },
    {
      onData: (data) => {
        context.document.getDocument.setData(
          { ownerId: documentOwnerId!, sessionId },
          () => {
            return { sessionDocuments: [data] };
          }
        );
      },
      enabled: documents.data != undefined,
    }
  );

  trpc.comment.onAddCommentThread.useSubscription(
    { documentId },
    {
      onData: () => {
        refetchCommentThreads();
      },
    }
  );

  trpc.comment.onAddCommentToThread.useSubscription(
    { documentOwnerId, activeHeaderIndex },
    {
      onData: (commentThreadData: any) => {
        addCommentToThread(
          commentThreadData.commentThreadId,
          {
            author: commentThreadData.author,
            creationTime: commentThreadData.creationTime,
            text: commentThreadData.text,
          },
          true
        );
      },
    }
  );

  const updateDocument = trpc.document.updateDocument.useMutation();

  const updateDocumentDebounced = debounce(
    (value: Descendant[], operations: BaseOperation[]) => {
      updateDocument.mutate({
        document: JSON.stringify(value),
        documentId,
        sessionId,
        operations,
      });
    },
    500
  );

  if (!documentOwnerId) return <p>Select a user from the session list</p>;
  if (documents.isLoading) return <ProgressSpinner />;
  if (!documents.data) return <p>"Document not found"</p>;

  return (
    <div className={cx("teacher-content-render")}>
      <SlateEditor
        isTeacher
        sessionStatus={session.data?.sessionStatus}
        savedOperations={documentOperations.data}
        onChange={updateDocumentDebounced}
        selectedView={selectedView}
        key={documents.data.sessionDocuments[0].document as string}
        document={
          JSON.parse(
            documents.data.sessionDocuments[0].document as string
          ) as Descendant[]
        }
      />
    </div>
  );
};
