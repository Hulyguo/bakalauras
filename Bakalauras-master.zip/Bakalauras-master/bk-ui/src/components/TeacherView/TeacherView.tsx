import { useState, useEffect, useRef } from "react";

import styles from "./teacher-view.module.scss";
import classNames from "classnames/bind";
import { StudentList } from "components/StudentList/StudentList";
import { Header } from "components/Header/Header";
import { TeacherContentRender } from "components/TeacherContentRender/TeacherContentRender";
import { useNavigate, useParams } from "react-router-dom";
import { trpc } from "utils/trpc";
import { SelectButton } from "primereact/selectbutton";
import { EditorCommentsProvider } from "components/Editor/providers/EditorCommentsProvider";
import { Toast } from "primereact/toast";

const cx = classNames.bind(styles);

export enum SidebarView {
  Messages = "Messages",
  Comments = "Comments",
}

export const TeacherView: React.FC = () => {
  const { data: myUserData } = trpc.authentication.myUser.useQuery();
  const navigate = useNavigate();
  const { sessionId } = useParams() as { sessionId: string };
  const toastRef = useRef<Toast | null>(null);
  const [selectedView, setSelectedView] = useState<SidebarView>(
    SidebarView.Messages
  );
  const [selectedOwnerId, setSelectedOwnerId] = useState<string | undefined>(
    undefined
  );
  const [newMessages, setNewMessages] = useState<any>({});
  const [activeHeaderIndex, setActiveHeaderIndex] = useState(0);

  const handler = (data: any, documentOwnerId?: string) => {
    const { senderId } = data;
    if (documentOwnerId === senderId && activeHeaderIndex === 1) return;

    if (senderId === myUserData?.user.id) {
      return;
    }

    setNewMessages((old: any, newMessage: any) => {
      const updatedMessages = { ...old };
      if (!updatedMessages[senderId]) updatedMessages[senderId] = [];
      updatedMessages[senderId].push(newMessage);
      return updatedMessages;
    });
  };

  const sessionMembersWithMesages =
    trpc.session.getSessionMembersWithMessages.useQuery(
      { sessionId },
      {
        refetchOnWindowFocus: false,
      }
    );

  trpc.message.onMessageSent.useSubscription(
    { sessionId },
    {
      onData: (data: any) => {
        console.log({ data });
        sessionMembersWithMesages.refetch();
        handler(data, selectedOwnerId);
      },
    }
  );

  const changeHeaderIndex = (index: number) => {
    setActiveHeaderIndex(index);
    if (index === 1) {
      delete newMessages[selectedOwnerId!];
    }
  };

  useEffect(() => {}, [selectedOwnerId]);

  const selectOptions = [
    {
      name: "Messages",
      value: SidebarView.Messages,
    },
    {
      name: "Comments",
      value: SidebarView.Comments,
    },
  ];

  trpc.session.onSessionStatusChange.useSubscription(
    { sessionId },
    {
      onData: () => {
        navigate(`/dashboard/session-ended/${sessionId}`);
      },
    }
  );

  return (
    <EditorCommentsProvider>
      <div className={`${cx("teacher-view")} w-full`}>
        <Toast ref={toastRef} />
        <div id="comment-sidebar" className={cx("teacher-view__sidebar")}>
          <SelectButton
            style={{ display: "flex", height: "3rem" }}
            itemTemplate={(item: (typeof selectOptions)[0]) => {
              if (item.value === SidebarView.Comments) {
                return (
                  <p
                    className={`${selectedView === SidebarView.Comments ? cx("teacher-view__select-button--active") : ""} ${cx("teacher-view__select-button")}`}
                  >
                    {item.name} <i className="pi pi-comment ml-2" />
                  </p>
                );
              } else {
                return (
                  <p
                    className={`${selectedView === SidebarView.Messages ? cx("teacher-view__select-button--active") : ""} ${cx("teacher-view__select-button")}`}
                  >
                    {item.name} <i className="pi pi-envelope ml-2" />
                  </p>
                );
              }
            }}
            className={cx("teacher-view__select")}
            options={selectOptions}
            optionLabel="name"
            value={selectedView}
            onChange={(e) => setSelectedView(e.value)}
          />
          {selectedView === SidebarView.Messages && (
            <StudentList
              documentOwnerId={selectedOwnerId}
              newMessages={newMessages}
              key={selectedOwnerId}
              onChange={(id: string) => {
                if (newMessages[id] && newMessages[id].length) {
                  setActiveHeaderIndex(1);
                }
                setSelectedOwnerId(id);
                delete newMessages[id];
              }}
            />
          )}
        </div>
        {selectedOwnerId && (
          <div className={cx("teacher-view__content")}>
            <Header
              key={activeHeaderIndex}
              setActiveHeaderIndex={changeHeaderIndex}
              activeHeaderIndex={activeHeaderIndex}
              messages={newMessages[selectedOwnerId]}
              documentOwnerId={selectedOwnerId}
              isTeacher
              contentRender={
                <TeacherContentRender
                  documentOwnerId={selectedOwnerId}
                  selectedView={selectedView}
                  HeaderIndex={activeHeaderIndex}
                />
              }
            />
          </div>
        )}
      </div>
    </EditorCommentsProvider>
  );
};
