import { Button } from "primereact/button";
import { Column, ColumnFilterElementTemplateOptions } from "primereact/column";
import {
  DataTable,
  DataTableExpandedRows,
  DataTableValueArray,
} from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { trpc } from "utils/trpc";
import { FilterMatchMode } from "primereact/api";
import { Calendar } from "primereact/calendar";
import { SessionStatus, UserSessionRole } from "types/enums";
import { Tag } from "primereact/tag";
import { Dropdown } from "primereact/dropdown";

export const UserSessions: React.FC = () => {
  const navigate = useNavigate();
  const [expandedRows, setExpandedRows] = useState<
    DataTableExpandedRows | DataTableValueArray | undefined
  >(undefined);
  const sessions = trpc.session.getUserSessions.useQuery();

  const [filters] = useState({
    role: { value: "", matchMode: FilterMatchMode.CONTAINS },
    "session.id": { value: "", matchMode: FilterMatchMode.CONTAINS },
    "session.sessionName": { value: "", matchMode: FilterMatchMode.CONTAINS },
    "session.sessionStatus": { value: "", matchMode: FilterMatchMode.CONTAINS },
    "session.startedAt": { value: "" },
  });

  const rowExpansionTemplate = (session: (typeof sessions.data)[0]) => {
    console.log(session.session.usersSessions);
    const grade =
      session.session?.usersSessions[0]?.sessionDocuments[0]?.grade ?? "-";
    return (
      <DataTable value={session.session.usersSessions}>
        <Column field="user.firstName" header="First name"></Column>
        <Column field="user.lastName" header="Last name"></Column>
        <Column body={() => <span>{grade}</span>} header="Grade"></Column>
      </DataTable>
    );
  };

  const allowExpansion = () => {
    return sessions.data && sessions.data?.length > 0;
  };

  const navigateToSession = (
    status: SessionStatus,
    sessionId: string,
    role: UserSessionRole,
    userSessions: any
  ) => {
    if (status === SessionStatus.Initialized) {
      return navigate(`/dashboard/session-lobby/${sessionId}`);
    }

    if (
      status === SessionStatus.Finalized ||
      status === SessionStatus.InProgress
    ) {
      if (role === UserSessionRole.ADMIN) {
        return navigate(`/dashboard/session-admin/${sessionId}`);
      }
      if (role === UserSessionRole.MEMBER) {
        return navigate(
          `/dashboard/session-user/${sessionId}/${userSessions.sessionDocuments[0].id}`
        );
      }
    }
  };

  const formatDate = (value: Date) => {
    return value?.toLocaleDateString("lt", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const dateBodyTemplate = (rowData: any) => {
    return formatDate(rowData.session.startedAt);
  };

  const dateFilterTemplate = (options: ColumnFilterElementTemplateOptions) => {
    return (
      <Calendar
        value={options.value}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        dateFormat="yy-mm-dd"
        placeholder="yyyy-mm-dd"
        mask="9999-99-99"
      />
    );
  };

  if (!sessions.data) {
    return null;
  }

  const statusItemTemplate = (option: string) => {
    switch (option) {
      case SessionStatus.Initialized:
        return <Tag value="Initialized" severity="warning" />;
      case SessionStatus.InProgress:
        return <Tag value="In progress" severity="info" />;
      case SessionStatus.Finalized:
        return <Tag value="Finalized" severity="success" />;
    }
  };

  const sessionRoleTemplate = (option: string) => {
    switch (option) {
      case UserSessionRole.ADMIN:
        return <Tag value="Admin" severity="warning" />;
      case UserSessionRole.MEMBER:
        return <Tag value="Member" severity="info" />;
    }
  };

  const statusRowFilterTemplate = (options) => {
    return (
      <Dropdown
        value={options.value}
        options={[
          SessionStatus.Initialized,
          SessionStatus.InProgress,
          SessionStatus.Finalized,
        ]}
        onChange={(e) => options.filterApplyCallback(e.value)}
        itemTemplate={statusItemTemplate}
        placeholder="Select One"
        className="p-column-filter"
        showClear
        style={{ minWidth: "12rem" }}
      />
    );
  };

  const userRoleFilterTemplate = (options) => {
    return (
      <Dropdown
        value={options.value}
        options={[UserSessionRole.ADMIN, UserSessionRole.MEMBER]}
        onChange={(e) => options.filterApplyCallback(e.value)}
        itemTemplate={sessionRoleTemplate}
        placeholder="Select One"
        className="p-column-filter"
        showClear
        style={{ minWidth: "12rem" }}
      />
    );
  };

  return (
    <div className="w-full">
      <div className="card overflow-y-scroll h-full">
        <DataTable
          paginator
          rows={10}
          dataKey="session.id"
          filterDisplay="row"
          filters={filters}
          value={sessions.data}
          expandedRows={expandedRows}
          onRowToggle={(e) => setExpandedRows(e.data)}
          rowExpansionTemplate={rowExpansionTemplate}
        >
          <Column expander={allowExpansion()} />
          <Column
            filter
            filterPlaceholder="Enter an id"
            field="session.id"
            header="Session id"
          />
          <Column
            filter
            field="role"
            header="Session role"
            options={[
              {
                name: UserSessionRole.ADMIN,
              },
              {
                name: UserSessionRole.MEMBER,
              },
            ]}
            filterElement={userRoleFilterTemplate}
            onChange={(e) => e.filterApplyCallback(e.value)}
            itemTemplate={sessionRoleTemplate}
          />
          <Column filter field="session.sessionName" header="Session name" />
          <Column
            sortable
            body={dateBodyTemplate}
            filter
            filterElement={dateFilterTemplate}
            dataType="date"
            field="session.startedAt"
            header="Started at"
          />
          <Column
            filter
            field="session.sessionStatus"
            header="Session status"
            options={[
              {
                name: SessionStatus.Initialized,
              },
              {
                name: SessionStatus.InProgress,
              },
              {
                name: SessionStatus.Finalized,
              },
            ]}
            filterElement={statusRowFilterTemplate}
            onChange={(e) => e.filterApplyCallback(e.value)}
            itemTemplate={statusItemTemplate}
            body={(data) => {
              const status: SessionStatus = data.session.sessionStatus;
              if (status === SessionStatus.Finalized) {
                return <Tag value="Finalized" severity="success" />;
              }

              if (status === SessionStatus.InProgress) {
                return <Tag value="In progress" severity="info" />;
              }

              if (status === SessionStatus.Initialized) {
                return <Tag value="Initialized" severity="warning" />;
              }
              return <div>{data.session.sessionStatus}</div>;
            }}
          />
          <Column
            body={(data) => (
              <Button
                label="Open session"
                onClick={() =>
                  navigateToSession(
                    data.session.sessionStatus,
                    data.session.id,
                    data.role,
                    data.session.usersSessions[0]
                  )
                }
              />
            )}
          />
        </DataTable>
      </div>
    </div>
  );
};
