import { Register } from "components/Register/Register";

import styles from "./user-settings.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

export const UserSettings: React.FC = () => {
  return (
    <div className={cx("user-settings")}>
      <Register />
    </div>
  );
};
