import { InputText } from "primereact/inputtext";
import { Controller, useFormContext } from "react-hook-form";
import { Field } from "components/Field/Field";
import { InputTextarea } from "primereact/inputtextarea";

interface BaseInputTextProps {
  formField: string;
  label: string;
  errorMessage?: string;
  iconNode?: React.ReactNode;
  textarea?: boolean;
  type?: "password" | "text" | "number";
}

export const BaseInputText: React.FC<BaseInputTextProps> = ({
  formField,
  errorMessage,
  label,
  iconNode,
  textarea,
  type = "text",
}) => {
  const formContext = useFormContext();

  return (
    <Field
      className="w-full"
      label={label}
      formField={formField}
      errorMessage={errorMessage}
    >
      <Controller
        name={formField}
        control={formContext.control}
        render={({ field }) => (
          <span className={` ${iconNode ? "p-input-icon-left" : "w-full"}`}>
            {iconNode}
            {!textarea && (
              <InputText
                {...field}
                type={type}
                className={`w-full ${errorMessage ? "p-invalid" : ""}`}
                placeholder={label}
              />
            )}
            {textarea && (
              <InputTextarea
                {...field}
                className={`w-full ${errorMessage ? "p-invalid" : ""}`}
                placeholder={label}
              />
            )}
          </span>
        )}
      />
    </Field>
  );
};
