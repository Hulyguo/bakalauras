import React, {
  useState,
  useContext,
  Dispatch,
  SetStateAction,
  useMemo,
} from "react";

interface AuthContextProviderProps {
  children: React.ReactNode;
}

export interface AuthContextType {
  csrfCookie: string | null;
  setCsrfCookie: Dispatch<SetStateAction<string | null>>;
  signOut: () => Promise<void>;
}

const AuthContext = React.createContext<AuthContextType | null>(null);

export const AuthContextProvider: React.FC<AuthContextProviderProps> = ({
  children,
}) => {
  const [csrfCookie, setCsrfCookie] = useState<string | null>(null);

  const signOut = async () => {};

  const value = useMemo(() => {
    return { csrfCookie, setCsrfCookie, signOut };
  }, [csrfCookie, setCsrfCookie, signOut]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuthContext = () => {
  const context = useContext(AuthContext);
  if (!context)
    throw new Error("useAuthContext must be used within the AuthProvider");

  return context;
};
