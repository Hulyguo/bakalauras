import { createBrowserRouter } from "react-router-dom";
import { Dashboard } from "components/Dashboard/Dashboard";
import { InitializeSessionForm } from "components/InitializeSessionForm/InitializeSessionForm";
import { JoinSessionForm } from "components/JoinSessionForm/JoinSessionForm";
import { Landing } from "components/Landing/Landing";
import { Login } from "components/Login/Login";
import { Logout } from "components/Logout/Logout";
import { ProtectedRoute } from "components/ProtectedRoute/ProtectedRoute";
import { Register } from "components/Register/Register";
import { SessionEnded } from "components/SessionEnded/SessionEnded";
import { SessionLobby } from "components/SessionLobby/SessionLobby";
import { StudentHome } from "components/StudentHome/StudentHome";
import { StudentView } from "components/StudentView/StudentView";
import { TeacherView } from "components/TeacherView/TeacherView";
import { UserSessions } from "components/UserSessions/UserSessions";
import { UserSettings } from "components/UserSettings/UserSettings";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Landing />,
    children: [
      {
        path: "register",
        element: <Register />,
      },
      {
        path: "login",
        element: <Login />,
      },
      {
        path: "logout",
        element: <Logout />,
      },
    ],
  },
  {
    path: "dashboard",
    element: (
      <ProtectedRoute>
        <Dashboard />
      </ProtectedRoute>
    ),
    children: [
      {
        path: "join-session",
        element: <JoinSessionForm />,
      },
      {
        path: "student-home",
        element: <StudentHome />,
      },
      {
        path: "initialize-session",
        element: <InitializeSessionForm />,
      },
      {
        path: "session-admin/:sessionId/:documentId?",
        element: <TeacherView />,
      },
      {
        path: "session-user/:sessionId/:documentId",
        element: <StudentView />,
      },
      {
        path: "session-lobby/:sessionId",
        element: <SessionLobby />,
      },
      {
        path: "user-sessions",
        element: <UserSessions />,
      },
      {
        path: "user-settings",
        element: <UserSettings />,
      },
      {
        path: "session-ended/:sessionId",
        element: <SessionEnded />,
      },
    ],
  },
]);
