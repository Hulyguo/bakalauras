export enum SessionStatus {
  Initialized = "Initialized",
  InProgress = "InProgress",
  Finalized = "Finalized",
}

export enum UserSessionRole {
  ADMIN = "ADMIN",
  MEMBER = "MEMBER",
}

export enum CommentThreadStatus {
  Open = "Open",
  Resolved = "Resolved",
}
