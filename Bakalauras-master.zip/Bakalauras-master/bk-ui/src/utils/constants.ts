export const AUTHENTICATION_COOKIE = "csrf_token";
