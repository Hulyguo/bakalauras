export const localStorageKeys = {
  LOCAL_SESSION_ID: "local-session-id",
};
