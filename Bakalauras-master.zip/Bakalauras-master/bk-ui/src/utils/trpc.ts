import {
  createTRPCReact,
  createWSClient,
  httpBatchLink,
  splitLink,
  wsLink,
} from "@trpc/react-query";
import type { AppRouter } from "../../../bk-backend/src/router/router";
import superjson from "superjson";

export const wsClient = createWSClient({
  url: "ws://localhost:3001/trpc",
});

export const trpc = createTRPCReact<AppRouter>();

export const createClient = (authCookie: string) =>
  trpc.createClient({
    transformer: superjson,
    links: [
      splitLink({
        condition: (op) => {
          return op.type === "subscription";
        },
        true: wsLink({ client: wsClient }),
        false: httpBatchLink({
          url: "http://localhost:3000/trpc",
          headers() {
            return {
              "csrf-token": authCookie,
            };
          },
          fetch(url, options) {
            return fetch(url, {
              ...options,
              credentials: "include",
            });
          },
        }),
      }),
    ],
  });
