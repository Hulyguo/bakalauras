import { z } from "zod";

export const trimmedString = z
  .string({ invalid_type_error: "Enter a value" })
  .min(1, { message: "Enter a value" })
  .trim();

export const password = z
  .string()
  .min(8, { message: "Password requires 8 characters" })
  .regex(/[$&+,:;=?@#|'<>.^*()%!-]/, { message: "Special symbol missing" });

export const ZodValidationUtils = {
  password,
  trimmedString,
};
